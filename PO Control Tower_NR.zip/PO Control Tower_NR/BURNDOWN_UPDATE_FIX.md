# Burndown Chart Update Fix - Detailed

## Issue
Burndown chart wasn't updating when you changed status of items.

## Root Cause
React wasn't detecting that the data had changed because:
1. Zustand state updates weren't triggering component re-renders properly
2. The Burndown component wasn't subscribed to the right state changes
3. Memoization was preventing recalculation

## Solution Applied

### **1. Added Data Version Counter** ✅
- Added `dataVersion` number to store state
- Increments every time data changes
- Forces components to re-render when data updates

### **2. Updated All Data Mutations** ✅
Now every data change increments dataVersion:
- `setRows()` → dataVersion++
- `updateRow()` → dataVersion++
- `updateRowStatus()` → dataVersion++  
- `recomputeDerived()` → dataVersion++

### **3. Burndown Subscribes to dataVersion** ✅
```typescript
const dataVersion = useStore((state) => state.dataVersion)
```
This forces the component to re-render whenever dataVersion changes.

### **4. Added Console Logging** ✅
To help verify it's working:
- Status change logs: "Status changed: X → Y for ID"
- Burndown logs: "dataVersion: N, Actioned this week: $XXX"

---

## How to Test

### **Quick Test**:
1. **Refresh your browser**
2. **Open browser console** (F12 or Cmd+Option+J)
3. **Change any row's status** to "Actioned"
4. **Watch the console** - you should see:
   ```
   Status changed: Not yet assessed → Actioned for DOC12345-10
   Burndown rendering - dataVersion: 1, Actioned this week: $45000
   ```
5. **Look at the burndown chart** - metrics should update
6. **Look at "Already Actioned"** value - should increase

### **Detailed Test**:
1. Note current "Already Actioned" value (e.g., $0)
2. Find a row with high excess value (e.g., $50,000)
3. Change its status from "Not yet assessed" → "Actioned"
4. **Immediately see**:
   - ✅ "Already Actioned" increases to $50,000
   - ✅ "Remaining" decreases by $50,000
   - ✅ Console shows the change
   - ✅ dataVersion increments
5. Change another item
6. **See cumulative effect**:
   - "Already Actioned" = $50,000 + new value
   - Chart continues to update

---

## What You Should See

### **In the Burndown Metrics Box**:
```
Burndown Metrics              Weekly Target
─────────────────            ────────────────
Starting Actionable: $411M   Goal: Reduce to 20% by week-end
Already Actioned: $50K  ← Should increase when you action items
Remaining: $410.95M     ← Should decrease
```

### **In the Browser Console**:
```
Status changed: Not yet assessed → Actioned for DOC10001-10-1
Burndown rendering - dataVersion: 1, Actioned this week: 50000
Status changed: In Progress → Actioned for DOC10002-15-2
Burndown rendering - dataVersion: 2, Actioned this week: 125000
```

---

## Why It Works Now

### Before:
```
Change status → updateRowStatus() → recomputeDerived() → updates rows
But... ❌ Burndown component doesn't know data changed
Result: ❌ No re-render, chart stays stale
```

### After:
```
Change status → updateRowStatus() → dataVersion++ → updates rows
Burndown subscribed to dataVersion → ✅ Detects change → ✅ Re-renders
Result: ✅ Chart updates immediately with new data
```

---

## Files Modified

1. **src/state/store.ts**
   - Added `dataVersion: number` to AppState
   - Increment dataVersion in: setRows, updateRow, updateRowStatus, recomputeDerived

2. **src/components/burndown/Burndown.tsx**
   - Subscribe to `dataVersion` from store
   - Added console logging for debugging

3. **src/components/table/StatusSelect.tsx**
   - Added console logging on status change

---

## Debug Console Logs

If it's still not working, check console for:
- ✅ "Status changed: X → Y" (confirms change happened)
- ✅ "Burndown rendering - dataVersion: N" (confirms re-render)
- ✅ "Actioned this week: $XXX" (shows calculated value)

If you don't see these logs, there's a deeper issue.

---

## Additional Checks

### Is the ChangeLog Being Created?
1. Change a status
2. Click the row to open detail drawer
3. Scroll down to "Change History"
4. **Should see the change** with timestamp

### Is the Status in "Actioned Statuses"?
The burndown only counts these statuses as "actioned":
- Actioned
- Approved Deviation
- Escalated / Pending
- Not yet assessed

If you're changing to a different status (like "In Progress"), it won't count.

### Is It This Week?
The burndown only counts changes made **this week** (current ISO week).
- Changes from last week won't show
- ChangeLog timestamp must be between weekStart and weekEnd

---

## Troubleshooting

If still not working after refresh:

1. **Hard refresh**: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
2. **Check console** for errors
3. **Try changing multiple items** to see cumulative effect
4. **Verify the status** you're changing to is in the "actioned" list
5. **Check the date** - item must be actioned this week

---

**The fix is comprehensive and should work!** Refresh and check the console logs to verify. 🔍



