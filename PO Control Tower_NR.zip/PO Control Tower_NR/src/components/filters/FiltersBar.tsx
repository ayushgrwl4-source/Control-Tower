import { useStore } from '@/state/store'
import { useFilterOptions } from '@/state/selectors'
import { Button } from '@/components/ui/button'
import { Search, X } from 'lucide-react'
import { useTransition } from 'react'

export function FiltersBar() {
  const [isPending, startTransition] = useTransition()
  const filters = useStore((state) => state.filters)
  const setFilter = useStore((state) => state.setFilter)
  const resetFilters = useStore((state) => state.resetFilters)
  const groupingMode = useStore((state) => state.ui.groupingMode)
  const setUI = useStore((state) => state.setUI)
  const { planners, vendors, plants, statuses, accountSpecialists, snapshotDates } = useFilterOptions()
  
  const handleGroupingChange = (value: string) => {
    startTransition(() => {
      setUI('groupingMode', value as any)
    })
  }

  return (
    <div className="mb-6 p-4 bg-card border rounded-lg space-y-4">
      {/* Search and Grouping */}
      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by Material, Vendor, Planner..."
            value={filters.search}
            onChange={(e) => setFilter('search', e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>

        <div className="flex items-center gap-2">
          <label className="text-sm font-medium">Group by:</label>
          <select
            value={groupingMode}
            onChange={(e) => handleGroupingChange(e.target.value)}
            disabled={isPending}
            className="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <option value="none">None</option>
            <option value="part">Part</option>
            <option value="vendor">Vendor</option>
            <option value="planner">Planner</option>
            <option value="accountSpecialist">Account Specialist</option>
            <option value="valueStream">Value Stream</option>
            <option value="businessUnit">Business Unit</option>
          </select>
          {isPending && <span className="text-xs text-muted-foreground">Processing...</span>}
        </div>

        <Button variant="outline" size="sm" onClick={resetFilters}>
          <X className="h-4 w-4 mr-2" />
          Reset Filters
        </Button>
      </div>

      {/* Filter Pills */}
      <div className="flex flex-wrap gap-4">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-muted-foreground">Planners</label>
          <select
            multiple
            value={filters.planners}
            onChange={(e) =>
              setFilter(
                'planners',
                Array.from(e.target.selectedOptions, (option) => option.value)
              )
            }
            className="px-2 py-1 border rounded text-sm h-20"
          >
            {planners.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-muted-foreground">Vendors</label>
          <select
            multiple
            value={filters.vendors}
            onChange={(e) =>
              setFilter(
                'vendors',
                Array.from(e.target.selectedOptions, (option) => option.value)
              )
            }
            className="px-2 py-1 border rounded text-sm h-20"
          >
            {vendors.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-muted-foreground">Plants</label>
          <select
            multiple
            value={filters.plants}
            onChange={(e) =>
              setFilter(
                'plants',
                Array.from(e.target.selectedOptions, (option) => option.value)
              )
            }
            className="px-2 py-1 border rounded text-sm h-20"
          >
            {plants.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-muted-foreground">Statuses</label>
          <select
            multiple
            value={filters.statuses}
            onChange={(e) =>
              setFilter(
                'statuses',
                Array.from(e.target.selectedOptions, (option) => option.value)
              )
            }
            className="px-2 py-1 border rounded text-sm h-20"
          >
            {statuses.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-muted-foreground">Account Specialists</label>
          <select
            multiple
            value={filters.accountSpecialists}
            onChange={(e) =>
              setFilter(
                'accountSpecialists',
                Array.from(e.target.selectedOptions, (option) => option.value)
              )
            }
            className="px-2 py-1 border rounded text-sm h-20"
          >
            {accountSpecialists.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </div>

        {/* RULE 5.1: Snapshot Date Filter */}
        {snapshotDates.length > 0 && (
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-muted-foreground">
              Snapshot Dates ({snapshotDates.length})
            </label>
            <select
              multiple
              value={filters.snapshotDates}
              onChange={(e) =>
                setFilter(
                  'snapshotDates',
                  Array.from(e.target.selectedOptions, (option) => option.value)
                )
              }
              className="px-2 py-1 border rounded text-sm h-20 min-w-[140px]"
              title="Select snapshot dates for table/scatterplot. Burndown shows all dates for trending."
            >
              {snapshotDates.map((date) => (
                <option key={date} value={date}>
                  {date}
                </option>
              ))}
            </select>
            <span className="text-xs text-muted-foreground">
              {filters.snapshotDates.length === 0 ? 'All dates' : 
               filters.snapshotDates.length === 1 ? 'Latest only' : 
               `${filters.snapshotDates.length} dates`}
            </span>
          </div>
        )}

        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-muted-foreground">Actionable Only</label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={filters.actionableOnly}
              onChange={(e) => setFilter('actionableOnly', e.target.checked)}
              className="w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
            />
            <span className="text-sm">Show only actionable</span>
          </label>
        </div>
      </div>
    </div>
  )
}


