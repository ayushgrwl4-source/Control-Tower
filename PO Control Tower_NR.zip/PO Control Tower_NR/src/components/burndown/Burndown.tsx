import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useFilteredRows } from '@/state/selectors'
import { useStore } from '@/state/store'
import { computeBurndown, computeKPIs } from '@/lib/kpi'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { formatCurrency } from '@/lib/utils'
import { useMemo } from 'react'

/**
 * RULE 6.3: Burndown chart with snapshot support
 */
export function Burndown() {
  const filteredRows = useFilteredRows()
  const allRows = useStore((state) => state.rows)
  const rules = useStore((state) => state.rules)
  const filters = useStore((state) => state.filters)
  const dataVersion = useStore((state) => state.dataVersion) // Force re-render on data changes

  // Detect if we have multiple snapshots
  const snapshotDates = useMemo(() => {
    const dates = new Set<string>()
    allRows.forEach(row => {
      if (row.SnapshotDate) dates.add(row.SnapshotDate)
    })
    return Array.from(dates).sort()
  }, [allRows])

  const hasMultipleSnapshots = snapshotDates.length > 1

  // RULE 6.3: Proper burndown chart with actual, target, and actioned lines
  const snapshotTrendData = useMemo(() => {
    if (!hasMultipleSnapshots) return null

    const dataPoints = snapshotDates.map(snapDate => {
      // Each snapshot is independent - not cumulative
      const snapshotRows = allRows.filter(row => row.SnapshotDate === snapDate)
      
      // Actual remaining opportunity at this snapshot (sum of ExcessValue)
      const actualRemaining = snapshotRows
        .filter(r => r.ActionableFlag)
        .reduce((sum, r) => sum + r.ExcessValue, 0)
      
      // Total actioned amount at this snapshot date (based on ActionedValue)
      const totalActioned = snapshotRows
        .filter(r => r.ActionableFlag)
        .reduce((sum, r) => sum + r.ActionedValue, 0)
      
      return {
        date: snapDate,
        actualRemaining,  // This is the sum of "Remaining Opportunity" column
        totalActioned,    // This is the sum of actioned amounts
        target: 0,        // Will be calculated below
      }
    })

    // Calculate target line: linear from initial to 20% by EOY
    if (dataPoints.length > 0) {
      const initialRemaining = dataPoints[0].actualRemaining
      const targetEnd = initialRemaining * 0.20  // 20% of initial (80% reduction)
      const eoyDate = '2025-12-31'
      
      // Calculate dates for interpolation
      const startDate = new Date(snapshotDates[0])
      const endDate = new Date(eoyDate)
      const totalDays = (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
      
      dataPoints.forEach((point) => {
        const pointDate = new Date(point.date)
        const daysSinceStart = (pointDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
        const progress = daysSinceStart / totalDays
        point.target = initialRemaining - (progress * (initialRemaining - targetEnd))
      })
    }

    return dataPoints
  }, [hasMultipleSnapshots, snapshotDates, allRows])

  const burndownData = computeBurndown(filteredRows, rules, filters.weekStart, filters.weekEnd)
  const kpis = computeKPIs(filteredRows, rules, filters.weekStart, filters.weekEnd)

  console.log('Burndown rendering - dataVersion:', dataVersion, 'Actioned this week:', kpis.dollarsActionedThisWeek)

  // RULE 6.3: Show snapshot trend if multiple snapshots, otherwise weekly burndown
  if (hasMultipleSnapshots && snapshotTrendData) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Excess Burndown (Target: 80% Reduction by EOY)</CardTitle>
            <Badge variant="outline">
              {snapshotDates[0]} → {snapshotDates[snapshotDates.length - 1]}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart 
              data={snapshotTrendData}
              margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(val) => {
                  return val // Already YYYY-MM-DD format
                }}
              />
              <YAxis 
                width={100}
                tickFormatter={(val) => {
                  // Simplified currency format for axis
                  if (val >= 1000000) return `$${(val / 1000000).toFixed(0)}M`
                  if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`
                  return `$${val}`
                }}
              />
              <Tooltip
                formatter={(value: number) => formatCurrency(value)}
                labelFormatter={(label) => `Snapshot: ${label}`}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="target"
                stroke="#10b981"
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Target (20% by EOY)"
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="actualRemaining"
                stroke="#3b82f6"
                strokeWidth={3}
                name="Actual Remaining"
                dot={true}
              />
              <Line
                type="monotone"
                dataKey="totalActioned"
                stroke="#f59e0b"
                strokeWidth={2}
                name="Actioned"
                dot={true}
              />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-4 text-sm">
            <div className="font-medium mb-1">Burndown Progress (Target: 80% reduction by EOY)</div>
            <div className="grid grid-cols-3 gap-4 text-muted-foreground">
              <div>
                <div className="font-medium text-foreground">Initial ({snapshotDates[0]})</div>
                <div className="mt-1">Remaining: {formatCurrency(snapshotTrendData[0].actualRemaining)}</div>
                <div>Actioned: {formatCurrency(snapshotTrendData[0].totalActioned)}</div>
              </div>
              <div>
                <div className="font-medium text-foreground">Current ({snapshotDates[snapshotDates.length - 1]})</div>
                <div className="mt-1">Remaining: {formatCurrency(snapshotTrendData[snapshotTrendData.length - 1].actualRemaining)}</div>
                <div>Actioned: {formatCurrency(snapshotTrendData[snapshotTrendData.length - 1].totalActioned)}</div>
              </div>
              <div>
                <div className="font-medium text-foreground">Target by EOY (12/31)</div>
                <div className="mt-1">
                  {formatCurrency(snapshotTrendData[0].actualRemaining * 0.20)}
                </div>
                <div className="text-xs mt-1">
                  Progress: {((1 - (snapshotTrendData[snapshotTrendData.length - 1].actualRemaining / snapshotTrendData[0].actualRemaining)) * 100).toFixed(1)}%
                </div>
                <div className="text-xs">
                  {snapshotTrendData[snapshotTrendData.length - 1].actualRemaining <= snapshotTrendData[snapshotTrendData.length - 1].target ? '✅ On Track' : '⚠️ Behind Target'}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Default: Weekly burndown view
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Weekly Burndown (80% Reduction Target)</CardTitle>
          <Badge variant={kpis.onTrack ? 'success' : 'destructive'}>
            {kpis.onTrack ? 'On Track' : 'Behind Target'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={burndownData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date" 
              tickFormatter={(val) => {
                const date = new Date(val)
                return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
              }}
            />
            <YAxis 
              tickFormatter={(val) => formatCurrency(val)}
            />
            <Tooltip
              formatter={(value: number) => formatCurrency(value)}
              labelFormatter={(label) => {
                const date = new Date(label)
                return date.toLocaleDateString('en-US', { 
                  weekday: 'short', 
                  month: 'short', 
                  day: 'numeric' 
                })
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="target"
              stroke="#10b981"
              strokeWidth={2}
              name="Target (80% reduction)"
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="actual"
              stroke="#3b82f6"
              strokeWidth={2}
              name="Actual Remaining"
              dot={true}
              connectNulls={false}
            />
          </LineChart>
        </ResponsiveContainer>
        <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="font-medium mb-1">Burndown Metrics</div>
            <div className="space-y-1 text-muted-foreground">
              <div>Starting Actionable: {formatCurrency(kpis.actionableExcess)}</div>
              <div>Already Actioned: {formatCurrency(kpis.dollarsActionedThisWeek)}</div>
              <div>Remaining: {formatCurrency(kpis.actionableExcess - kpis.dollarsActionedThisWeek)}</div>
            </div>
          </div>
          <div>
            <div className="font-medium mb-1">Weekly Target</div>
            <div className="space-y-1 text-muted-foreground">
              <div>Goal: Reduce to 20% by week-end</div>
              <div>Target Remaining: {formatCurrency(kpis.actionableExcess * 0.2)}</div>
              <div>Required Action: {formatCurrency(kpis.actionableExcess * 0.8)}</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}


