import { Button } from '@/components/ui/button'
import { useFilteredRows } from '@/state/selectors'
import { exportToExcel } from '@/lib/excel'
import { Download } from 'lucide-react'

export function ExportButton() {
  const filteredRows = useFilteredRows()

  const handleExport = () => {
    const filename = `po-control-tower-export-${new Date().toISOString().split('T')[0]}.xlsx`
    exportToExcel(filteredRows, {
      filename,
      includeFilters: true,
      selectedOnly: false,
    })
  }

  return (
    <Button variant="outline" onClick={handleExport} disabled={filteredRows.length === 0}>
      <Download className="h-4 w-4 mr-2" />
      Export Current View
    </Button>
  )
}




