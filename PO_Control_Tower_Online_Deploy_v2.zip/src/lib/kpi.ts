import { ExceptionRow, KPIData, RulesConfig, BurndownPoint } from '@/types'
import { isActionedStatus } from './rules'
import { startOfISOWeek, endOfISOWeek, addDays, parseISO } from 'date-fns'

/**
 * Compute KPI metrics for the current filter context and time window
 */
export function computeKPIs(
  rows: ExceptionRow[],
  rules: RulesConfig,
  weekStart: Date,
  weekEnd: Date
): KPIData {
  // KPI-1: Total Excess
  const totalExcess = rows.reduce((sum, row) => sum + row.ExcessValue, 0)

  // KPI-2: Actionable Excess
  const actionableExcess = rows
    .filter((row) => row.ActionableFlag)
    .reduce((sum, row) => sum + row.ExcessValue, 0)

  // Detect currencies
  const currencies = [...new Set(rows.map((r) => r.Currency || 'USD').filter(Boolean))]
  const currencyMixed = currencies.length > 1

  // Weekly metrics
  const weeklyMetrics = computeWeeklyMetrics(rows, rules, weekStart, weekEnd)

  // KPI-3: Weekly Clearance %
  const weeklyClearancePct =
    weeklyMetrics.newActionableDollarsThisWeek > 0
      ? Math.min(
          100,
          (weeklyMetrics.dollarsActionedThisWeek / weeklyMetrics.newActionableDollarsThisWeek) * 100
        )
      : 0

  // KPI-3: Overall Burn %
  const totalActionable =
    weeklyMetrics.openingActionableBacklog + weeklyMetrics.newActionableDollarsThisWeek
  const overallBurnPct =
    totalActionable > 0 ? (weeklyMetrics.dollarsActionedThisWeek / totalActionable) * 100 : 0

  // On-track if we're meeting the 80% weekly reduction target
  const onTrack = overallBurnPct >= 80

  return {
    totalExcess,
    actionableExcess,
    weeklyClearancePct,
    overallBurnPct,
    dollarsActionedThisWeek: weeklyMetrics.dollarsActionedThisWeek,
    newActionableDollarsThisWeek: weeklyMetrics.newActionableDollarsThisWeek,
    openingActionableBacklog: weeklyMetrics.openingActionableBacklog,
    onTrack,
    currencyMixed,
    currencies,
  }
}

/**
 * Compute weekly metrics for burndown tracking
 */
function computeWeeklyMetrics(
  rows: ExceptionRow[],
  rules: RulesConfig,
  weekStart: Date,
  weekEnd: Date
) {
  // Total actionable excess (starting point)
  const totalActionableExcess = rows
    .filter((row) => row.ActionableFlag)
    .reduce((sum, row) => sum + row.ExcessValue, 0)

  // Remaining actionable (not yet actioned)
  const remainingActionable = rows
    .filter((row) => row.ActionableFlag && !isActionedStatus(row.CurrentStatus, rules))
    .reduce((sum, row) => sum + row.ExcessValue, 0)

  // For the weekly burndown:
  // Opening backlog = total actionable at start of week (simplified: use total actionable)
  const openingActionableBacklog = totalActionableExcess

  // New this week: items with ExceptionDate in current week
  const newActionableDollarsThisWeek = rows
    .filter((row) => {
      if (!row.ActionableFlag) return false
      if (!row.ExceptionDate) return false
      try {
        const exDate = parseISO(row.ExceptionDate)
        return exDate >= weekStart && exDate <= weekEnd
      } catch {
        return false
      }
    })
    .reduce((sum, row) => sum + row.ExcessValue, 0)

  // Dollars actioned THIS WEEK: check ChangeLog for status changes that happened this week
  const dollarsActionedThisWeek = rows
    .filter((row) => {
      if (!row.ActionableFlag) return false
      if (!isActionedStatus(row.CurrentStatus, rules)) return false
      
      // Check if this status was set during the current week
      // Look for the most recent status change to an actioned status
      const statusChanges = row.ChangeLog.filter(
        entry => entry.field === 'CurrentStatus' && isActionedStatus(entry.newValue || '', rules)
      )
      
      if (statusChanges.length === 0) {
        // No history, assume it was already actioned (not this week)
        return false
      }
      
      // Get the most recent actioned status change
      const lastActionedChange = statusChanges[statusChanges.length - 1]
      const changeDate = new Date(lastActionedChange.timestamp)
      
      return changeDate >= weekStart && changeDate <= weekEnd
    })
    .reduce((sum, row) => sum + row.ExcessValue, 0)

  return {
    openingActionableBacklog,
    newActionableDollarsThisWeek,
    dollarsActionedThisWeek,
    remainingActionable,
    totalActionableExcess,
  }
}

/**
 * Compute burndown target and actual series for chart
 */
export function computeBurndown(
  rows: ExceptionRow[],
  rules: RulesConfig,
  weekStart: Date,
  weekEnd: Date
): BurndownPoint[] {
  const metrics = computeWeeklyMetrics(rows, rules, weekStart, weekEnd)
  
  // Start with total actionable excess at beginning of week
  const startingTotal = metrics.totalActionableExcess
  const targetReduction = startingTotal * 0.8 // 80% reduction goal

  const points: BurndownPoint[] = []
  const daysInWeek = 7
  const today = new Date()
  today.setHours(0, 0, 0, 0) // Normalize to start of day

  // Calculate daily actioned amounts
  const dailyActioned = new Map<string, number>()
  
  rows.forEach((row) => {
    if (!row.ActionableFlag) return
    if (!isActionedStatus(row.CurrentStatus, rules)) return
    
    // Find when this item was actioned
    const statusChanges = row.ChangeLog.filter(
      entry => entry.field === 'CurrentStatus' && isActionedStatus(entry.newValue || '', rules)
    )
    
    if (statusChanges.length > 0) {
      const lastActionedChange = statusChanges[statusChanges.length - 1]
      const changeDate = new Date(lastActionedChange.timestamp)
      
      // Get local date string to avoid timezone issues
      const year = changeDate.getFullYear()
      const month = String(changeDate.getMonth() + 1).padStart(2, '0')
      const day = String(changeDate.getDate()).padStart(2, '0')
      const dateKey = `${year}-${month}-${day}`
      
      // Normalize for comparison (use local date)
      const changeDateNormalized = new Date(year, changeDate.getMonth(), changeDate.getDate())
      
      // Only count if within this week
      if (changeDateNormalized >= weekStart && changeDateNormalized <= weekEnd) {
        dailyActioned.set(dateKey, (dailyActioned.get(dateKey) || 0) + row.ExcessValue)
      }
    }
  })

  // Build daily progression
  let cumulativeActioned = 0
  
  for (let d = 0; d <= daysInWeek; d++) {
    const date = addDays(weekStart, d)
    const dateStr = date.toISOString().split('T')[0]

    // Target: linear reduction from startingTotal to 20% by end of week
    const target = startingTotal - (targetReduction * d) / daysInWeek

    // Actual: Only show up to today's date
    let actual: number | null = null
    if (date <= today) {
      // Add actioned amount for this day
      cumulativeActioned += dailyActioned.get(dateStr) || 0
      
      // Actual remaining = starting total - cumulative actioned
      actual = startingTotal - cumulativeActioned
    }

    points.push({
      day: d,
      date: dateStr,
      target: Math.max(0, target),
      actual: actual !== null ? Math.max(0, actual) : null,
    })
  }

  return points
}

/**
 * Get current ISO week boundaries
 */
export function getCurrentWeekBounds(): { weekStart: Date; weekEnd: Date } {
  const now = new Date()
  return {
    weekStart: startOfISOWeek(now),
    weekEnd: endOfISOWeek(now),
  }
}

