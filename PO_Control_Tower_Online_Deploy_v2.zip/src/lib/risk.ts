import { ExceptionRow } from '@/types'

/**
 * Calculate inventory risk for a given date
 * Risk occurs when:
 * - Delivery Date is BEFORE the selected date (item was supposed to arrive)
 * - Reschedule Date is AFTER the selected date (item has been delayed)
 * This creates inventory shortage risk if exception is not actioned
 */
export function calculateInventoryRisk(rows: ExceptionRow[], riskDate: Date | null): {
  riskValue: number
  riskCount: number
  riskRows: ExceptionRow[]
} {
  if (!riskDate) {
    return { riskValue: 0, riskCount: 0, riskRows: [] }
  }

  const riskRows = rows.filter((row) => {
    // Both dates must exist
    if (!row.DeliveryDate || !row.PushOutToDate) {
      return false
    }

    try {
      const deliveryDate = new Date(row.DeliveryDate)
      const rescheduleDate = new Date(row.PushOutToDate)
      const targetDate = new Date(riskDate)

      // Normalize to start of day for comparison
      deliveryDate.setHours(0, 0, 0, 0)
      rescheduleDate.setHours(0, 0, 0, 0)
      targetDate.setHours(0, 0, 0, 0)

      // Risk = Delivery was before target date, but rescheduled to after
      return deliveryDate < targetDate && rescheduleDate > targetDate
    } catch {
      return false
    }
  })

  const riskValue = riskRows.reduce((sum, row) => sum + row.ExcessValue, 0)
  const riskCount = riskRows.length

  return { riskValue, riskCount, riskRows }
}



