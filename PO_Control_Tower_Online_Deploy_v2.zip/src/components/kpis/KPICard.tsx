import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { formatCurrency, formatNumber } from '@/lib/utils'
import { HelpCircle } from 'lucide-react'

interface KPICardProps {
  title: string
  value: number | string
  subtitle?: string
  format?: 'currency' | 'number' | 'percent'
  tooltip?: string
  badge?: React.ReactNode
}

export function KPICard({ title, value, subtitle, format = 'number', tooltip, badge }: KPICardProps) {
  const formattedValue =
    typeof value === 'number'
      ? format === 'currency'
        ? formatCurrency(value)
        : format === 'percent'
        ? `${value.toFixed(1)}%`
        : formatNumber(value)
      : value

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {tooltip && (
          <div className="relative group">
            <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
            <div className="absolute right-0 top-6 w-64 p-2 bg-popover text-popover-foreground text-xs rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity z-50 border">
              {tooltip}
            </div>
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-2">
          <div className="text-2xl font-bold">{formattedValue}</div>
          {badge}
        </div>
        {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
      </CardContent>
    </Card>
  )
}




