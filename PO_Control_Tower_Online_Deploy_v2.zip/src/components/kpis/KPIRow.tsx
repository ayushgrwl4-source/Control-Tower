import { useFilteredRows } from '@/state/selectors'
import { useStore } from '@/state/store'
import { computeKPIs } from '@/lib/kpi'
import { KPICard } from './KPICard'
import { RiskKPI } from './RiskKPI'
import { Badge } from '@/components/ui/badge'
import { formatCurrency } from '@/lib/utils'

export function KPIRow() {
  const filteredRows = useFilteredRows()
  const rules = useStore((state) => state.rules)
  const filters = useStore((state) => state.filters)
  const riskDate = useStore((state) => state.filters.riskDate)

  const kpis = computeKPIs(filteredRows, rules, filters.weekStart, filters.weekEnd)

  const currencyWarning = kpis.currencyMixed
    ? `Mixed currencies detected: ${kpis.currencies.join(', ')}`
    : ''

  return (
    <div className={`grid gap-4 mb-6 ${riskDate ? 'md:grid-cols-4' : 'md:grid-cols-3'}`}>
      <KPICard
        title="Total Excess"
        value={kpis.totalExcess}
        format="currency"
        subtitle={currencyWarning || `${filteredRows.length} exceptions`}
        tooltip={`Sum of ExcessValue across ${filteredRows.length} exceptions in current filter. ${currencyWarning}`}
      />

      <KPICard
        title="Actionable Excess"
        value={kpis.actionableExcess}
        format="currency"
        subtitle="Based on current rules"
        tooltip={`Sum of ExcessValue where ActionableFlag = true. Rules sourced from: ${rules.sourceField}`}
      />

      <KPICard
        title="% Actioned"
        value={kpis.overallBurnPct}
        format="percent"
        subtitle={`${formatCurrency(kpis.dollarsActionedThisWeek)} / ${formatCurrency(
          kpis.openingActionableBacklog + kpis.newActionableDollarsThisWeek
        )}`}
        tooltip={`Overall Burn %: DollarsActionedThisWeek (${formatCurrency(
          kpis.dollarsActionedThisWeek
        )}) / (OpeningBacklog (${formatCurrency(
          kpis.openingActionableBacklog
        )}) + NewThisWeek (${formatCurrency(kpis.newActionableDollarsThisWeek)}))`}
        badge={
          <Badge variant={kpis.onTrack ? 'success' : 'destructive'}>
          {kpis.onTrack ? 'On Track' : 'Behind'}
        </Badge>
      }
      />
      
      {riskDate && <RiskKPI />}
    </div>
  )
}


