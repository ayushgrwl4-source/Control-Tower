import { useMemo, useState, useRef } from 'react'
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  ColumnDef,
  flexRender,
  SortingState,
} from '@tanstack/react-table'
import { useVirtualizer } from '@tanstack/react-virtual'
import { ExceptionRow, GroupedRow, TableRow } from '@/types'
import { useTableRows } from '@/state/selectors'
import { useStore } from '@/state/store'
import { ThermometerCell } from './ThermometerCell'
import { StatusSelect } from './StatusSelect'
import { RejectionSelect } from './RejectionSelect'
import { formatNumber, formatDate } from '@/lib/utils'
import { ChevronDown, ChevronRight } from 'lucide-react'
import { Card } from '@/components/ui/card'

export function ActionBoard() {
  const tableRows = useTableRows()
  const groupingMode = useStore((state) => state.ui.groupingMode)
  const openDrawer = useStore((state) => state.openDrawer)
  const [sorting, setSorting] = useState<SortingState>([])
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set())
  
  const tableContainerRef = useRef<HTMLDivElement>(null)
  
  // Reset expanded groups when grouping mode changes
  useMemo(() => {
    setExpandedGroups(new Set())
  }, [groupingMode])

  // Calculate max value for proportional bar scaling
  const maxValue = useMemo(() => {
    if (groupingMode !== 'none') {
      return Math.max(...tableRows.map(row => 
        'isGroup' in row && row.isGroup ? (row as GroupedRow).totalExcessValue : 0
      ), 0)
    } else {
      return Math.max(...tableRows.map(row => 
        'ExcessValue' in row ? (row as ExceptionRow).ExcessValue : 0
      ), 0)
    }
  }, [tableRows, groupingMode])

  const columns = useMemo<ColumnDef<TableRow>[]>(() => {
    if (groupingMode !== 'none') {
      // Grouped columns
      return [
        {
          id: 'expander',
          header: '',
          cell: ({ row }) => {
            const grouped = row.original as GroupedRow
            const isExpanded = expandedGroups.has(grouped.groupKey)
            return (
              <button
                onClick={() => {
                  const newExpanded = new Set(expandedGroups)
                  if (isExpanded) {
                    newExpanded.delete(grouped.groupKey)
                  } else {
                    newExpanded.add(grouped.groupKey)
                  }
                  setExpandedGroups(newExpanded)
                }}
                className="p-1 hover:bg-gray-100 rounded"
              >
                {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </button>
            )
          },
          size: 40,
        },
        {
          accessorKey: 'groupLabel',
          header: 'Group',
          cell: ({ row }) => {
            const grouped = row.original as GroupedRow
            return (
              <div className="font-medium">
                {grouped.groupLabel} <span className="text-muted-foreground">({grouped.rows.length})</span>
              </div>
            )
          },
        },
        {
          id: 'value',
          header: 'Total Value',
          cell: ({ row }) => {
            const grouped = row.original as GroupedRow
            return (
              <ThermometerCell
                excessValue={grouped.totalExcessValue}
                actionedValue={grouped.totalActionedValue}
                thermometerPct={grouped.thermometerPct}
                maxValue={maxValue}
              />
            )
          },
          size: 250,
        },
        {
          id: 'units',
          header: 'Total Units',
          cell: ({ row }) => {
            const grouped = row.original as GroupedRow
            return formatNumber(grouped.totalUnitsExcess)
          },
        },
        {
          id: 'pnEmCode',
          header: 'PN EM Code Desc',
          cell: ({ row }) => {
            const grouped = row.original as GroupedRow
            // Show the most common PN EM Code Desc in this group
            const counts = new Map<string, number>()
            grouped.rows.forEach(r => {
              const code = r.ExistingCategorization || 'Unknown'
              counts.set(code, (counts.get(code) || 0) + 1)
            })
            
            // Find most common
            let mostCommon = 'Unknown'
            let maxCount = 0
            counts.forEach((count, code) => {
              if (count > maxCount) {
                maxCount = count
                mostCommon = code
              }
            })
            
            const uniqueCount = counts.size
            
            return (
              <div className="max-w-xs">
                <div className="truncate" title={mostCommon}>
                  {mostCommon}
                </div>
                {uniqueCount > 1 && (
                  <div className="text-xs text-muted-foreground">
                    +{uniqueCount - 1} other{uniqueCount > 2 ? 's' : ''}
                  </div>
                )}
              </div>
            )
          },
          size: 150,
        },
      ]
    }

    // Individual row columns
    return [
      {
        id: 'value',
        header: 'Value (Bar Chart)',
        cell: ({ row }) => {
          const data = row.original as ExceptionRow
          return (
            <ThermometerCell
              excessValue={data.ExcessValue}
              actionedValue={data.ActionedValue}
              thermometerPct={data.ThermometerPct}
              maxValue={maxValue}
            />
          )
        },
        size: 250,
      },
      {
        accessorKey: 'Material',
        header: 'Material',
        cell: ({ row }) => {
          const data = row.original as ExceptionRow
          return <div className="font-medium">{data.Material}</div>
        },
        size: 120,
      },
      {
        accessorKey: 'MaterialName',
        header: 'Material Name',
        cell: ({ row }) => {
          const data = row.original as ExceptionRow
          return (
            <div className="max-w-xs truncate" title={data.MaterialName || ''}>
              {data.MaterialName || '—'}
            </div>
          )
        },
        size: 200,
      },
      {
        accessorKey: 'VendorName',
        header: 'Vendor',
      },
      {
        accessorKey: 'Planner',
        header: 'Planner',
      },
      {
        accessorKey: 'UnitsExcess',
        header: 'Units Excess',
        cell: ({ row }) => formatNumber((row.original as ExceptionRow).UnitsExcess),
      },
      {
        accessorKey: 'DaysOfInventoryOnHand',
        header: 'DIO',
        cell: ({ row }) => {
          const dio = (row.original as ExceptionRow).DaysOfInventoryOnHand
          return dio !== null ? formatNumber(dio) : '—'
        },
      },
      {
        accessorKey: 'ActionCategory',
        header: 'Action Category',
        cell: ({ row }) => (row.original as ExceptionRow).ActionCategory || '—',
      },
      {
        accessorKey: 'CurrentStatus',
        header: 'Status',
        cell: ({ row }) => {
          const data = row.original as ExceptionRow
          return <StatusSelect exceptionId={data.ExceptionId} currentStatus={data.CurrentStatus} />
        },
        size: 200,
      },
      {
        accessorKey: 'RejectionCause',
        header: 'Rejection Cause',
        cell: ({ row }) => {
          const data = row.original as ExceptionRow
          return <RejectionSelect exceptionId={data.ExceptionId} currentRejectionCause={data.RejectionCause} />
        },
        size: 240,
      },
      {
        accessorKey: 'ExistingCategorization',
        header: 'PN EM Code Desc',
        cell: ({ row }) => (row.original as ExceptionRow).ExistingCategorization || '—',
        size: 150,
      },
      {
        accessorKey: 'PushOutToDate',
        header: 'Push Out Date',
        cell: ({ row }) => formatDate((row.original as ExceptionRow).PushOutToDate),
      },
      {
        accessorKey: 'Constraints',
        header: 'Constraints',
        cell: ({ row }) => {
          const constraints = (row.original as ExceptionRow).Constraints
          const text = constraints.join('; ')
          return (
            <div className="max-w-xs truncate" title={text}>
              {text || '—'}
            </div>
          )
        },
      },
    ]
  }, [groupingMode, maxValue])

  const table = useReactTable({
    data: tableRows,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
  })

  const { rows } = table.getRowModel()

  // Virtual scrolling - only render visible rows
  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => tableContainerRef.current,
    estimateSize: () => 60, // Estimate row height
    overscan: 10, // Render 10 extra rows above/below viewport
  })

  const handleRowClick = (row: TableRow) => {
    if ('isGroup' in row && row.isGroup) {
      // Toggle expand for group
      const newExpanded = new Set(expandedGroups)
      if (expandedGroups.has(row.groupKey)) {
        newExpanded.delete(row.groupKey)
      } else {
        newExpanded.add(row.groupKey)
      }
      setExpandedGroups(newExpanded)
    } else {
      // Open drawer for individual row
      openDrawer((row as ExceptionRow).ExceptionId)
    }
  }

  const virtualRows = rowVirtualizer.getVirtualItems()
  const totalSize = rowVirtualizer.getTotalSize()
  const paddingTop = virtualRows.length > 0 ? virtualRows[0]?.start || 0 : 0
  const paddingBottom =
    virtualRows.length > 0
      ? totalSize - (virtualRows[virtualRows.length - 1]?.end || 0)
      : 0

  return (
    <Card className="mb-6" key={groupingMode}>
      <div className="px-4 py-2 border-b bg-muted/30 text-xs text-muted-foreground flex items-center justify-between">
        <span>
          Showing {tableRows.length.toLocaleString()} {groupingMode !== 'none' ? 'groups' : 'exceptions'}
          {tableRows.length > 100 && ' (virtualized for performance)'}
        </span>
        <span className="italic">
          {tableRows.length > 1000 ? '⚡ Virtual scrolling active' : 'Tip: Use filters to narrow results'}
        </span>
      </div>
      <div 
        ref={tableContainerRef}
        className="overflow-auto"
        style={{ maxHeight: '600px' }}
      >
        <table className="w-full">
          <thead className="bg-muted/50 border-b sticky top-0 z-10">
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    key={header.id}
                    className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider bg-muted/50"
                    style={{ width: header.column.columnDef.size }}
                  >
                    {header.isPlaceholder
                      ? null
                      : flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="bg-background divide-y">
            {paddingTop > 0 && (
              <tr>
                <td style={{ height: `${paddingTop}px` }} />
              </tr>
            )}
            {virtualRows.map((virtualRow) => {
              const row = rows[virtualRow.index]
              return (
              <>
                <tr
                  key={row.id}
                  className="hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => handleRowClick(row.original)}
                >
                  {row.getVisibleCells().map((cell) => (
                    <td
                      key={cell.id}
                      className="px-4 py-3 text-sm"
                      onClick={(e) => {
                        // Prevent row click when clicking on select
                        if ((e.target as HTMLElement).tagName === 'SELECT') {
                          e.stopPropagation()
                        }
                      }}
                    >
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
                {/* Render expanded group rows */}
                {'isGroup' in row.original &&
                  row.original.isGroup &&
                  expandedGroups.has((row.original as GroupedRow).groupKey) &&
                  (row.original as GroupedRow).rows.map((childRow) => (
                    <tr
                      key={childRow.ExceptionId}
                      className="bg-muted/20 hover:bg-muted/40 cursor-pointer"
                      onClick={() => openDrawer(childRow.ExceptionId)}
                    >
                      <td className="px-4 py-2"></td>
                      <td className="px-4 py-2 text-sm" colSpan={columns.length - 1}>
                        <div className="grid grid-cols-7 gap-2 text-xs">
                          <div>
                            <span className="font-medium">{childRow.Material}</span>
                            {childRow.MaterialName && (
                              <div className="text-muted-foreground">{childRow.MaterialName}</div>
                            )}
                          </div>
                          <div>{childRow.VendorName}</div>
                          <div>{childRow.Planner}</div>
                          <div>{formatNumber(childRow.UnitsExcess)} units</div>
                          <div>
                            <StatusSelect
                              exceptionId={childRow.ExceptionId}
                              currentStatus={childRow.CurrentStatus}
                            />
                          </div>
                          <div>
                            <RejectionSelect
                              exceptionId={childRow.ExceptionId}
                              currentRejectionCause={childRow.RejectionCause}
                            />
                          </div>
                          <div>
                            <ThermometerCell
                              excessValue={childRow.ExcessValue}
                              actionedValue={childRow.ActionedValue}
                              thermometerPct={childRow.ThermometerPct}
                              maxValue={maxValue}
                            />
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
              </>
              )
            })}
            {paddingBottom > 0 && (
              <tr>
                <td style={{ height: `${paddingBottom}px` }} />
              </tr>
            )}
          </tbody>
        </table>
        {tableRows.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No exceptions found. Upload data to get started.
          </div>
        )}
      </div>
    </Card>
  )
}


