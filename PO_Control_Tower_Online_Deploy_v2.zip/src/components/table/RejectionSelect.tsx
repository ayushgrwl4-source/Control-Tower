import { useStore } from '@/state/store'
import { memo } from 'react'

interface RejectionSelectProps {
  exceptionId: string
  currentRejectionCause?: string | null
}

export const RejectionSelect = memo(function RejectionSelect({ 
  exceptionId, 
  currentRejectionCause 
}: RejectionSelectProps) {
  const updateRowRejectionCause = useStore((state) => state.updateRowRejectionCause)
  const currentUser = useStore((state) => state.currentUser)

  // Placeholder rejection causes - will be updated later per user request
  const rejectionCauses = [
    { value: '', label: 'No Rejection' },
    { value: 'DUPLICATE_ORDER', label: 'Duplicate Order' },
    { value: 'ALREADY_RESOLVED', label: 'Already Resolved' },
    { value: 'CONTRACTUAL_OBLIGATION', label: 'Contractual Obligation' },
    { value: 'SUPPLIER_COMMITMENT', label: 'Supplier Commitment' },
    { value: 'DOWNSTREAM_DEPENDENCY', label: 'Downstream Dependency' },
    { value: 'PRODUCTION_REQUIREMENT', label: 'Production Requirement' },
    { value: 'INCORRECT_DATA', label: 'Incorrect Data' },
    { value: 'CUSTOMER_REQUIREMENT', label: 'Customer Requirement' },
    { value: 'OTHER', label: 'Other - See Notes' },
  ]

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newCause = e.target.value || null
    updateRowRejectionCause(exceptionId, newCause, currentUser)
    console.log(`Rejection cause changed: ${currentRejectionCause || 'none'} → ${newCause || 'none'} for ${exceptionId}`)
  }

  return (
    <select
      value={currentRejectionCause || ''}
      onChange={handleChange}
      className="w-full px-2 py-1 text-sm border rounded focus:outline-none focus:ring-2 focus:ring-primary bg-background"
    >
      {rejectionCauses.map((cause) => (
        <option key={cause.value} value={cause.value}>
          {cause.label}
        </option>
      ))}
    </select>
  )
})

