import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { useStore } from '@/state/store'
import { parseInventoryFile } from '@/lib/inventory'
import { Database } from 'lucide-react'

export function InventoryUploadButton() {
  const [loading, setLoading] = useState(false)
  const setInventoryMap = useStore((state) => state.setInventoryMap)
  const inventoryMap = useStore((state) => state.inventoryMap)

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setLoading(true)
    try {
      const map = await parseInventoryFile(file)
      setInventoryMap(map)
      
      // Check if we have requirements data
      let hasRequirements = false
      for (const inv of map.values()) {
        if (inv.next_1year_requirements && inv.next_1year_requirements > 0) {
          hasRequirements = true
          break
        }
      }
      
      if (hasRequirements) {
        alert(`✓ Successfully loaded inventory data for ${map.size} Material-Plant combinations.\n✓ DIO values will be automatically calculated.`)
      } else {
        alert(
          `⚠️  Loaded ${map.size} inventory records, but no annual requirements data found.\n\n` +
          `To calculate DIO, your file needs a column called:\n` +
          `  • "next_1year_requirements" (annual demand)\n\n` +
          `Current file has: material_number, plant, unrestricted_stock_quantity, etc.\n\n` +
          `DIO calculation: unrestricted_stock_quantity / (next_1year_requirements / working_days)`
        )
      }
    } catch (error) {
      console.error('Inventory import error:', error)
      alert(`Failed to import inventory data: ${(error as Error).message}`)
    } finally {
      setLoading(false)
      e.target.value = ''
    }
  }

  return (
    <div>
      <input
        type="file"
        accept=".xlsx,.xls"
        onChange={handleFileUpload}
        className="hidden"
        id="inventory-upload"
      />
      <label htmlFor="inventory-upload" className="cursor-pointer">
        <Button 
          disabled={loading}
          variant={inventoryMap.size > 0 ? "default" : "outline"}
          onClick={() => document.getElementById('inventory-upload')?.click()}
        >
          <Database className="h-4 w-4 mr-2" />
          {loading 
            ? 'Loading...' 
            : inventoryMap.size > 0 
            ? `DIO Data (${inventoryMap.size})` 
            : 'Import DIO Data'}
        </Button>
      </label>
    </div>
  )
}

