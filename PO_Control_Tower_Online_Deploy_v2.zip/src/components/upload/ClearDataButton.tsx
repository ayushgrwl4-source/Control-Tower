import { Button } from '@/components/ui/button'
import { useStore } from '@/state/store'
import { Trash2 } from 'lucide-react'

export function ClearDataButton() {
  const clearAllData = useStore((state) => state.clearAllData)
  const rowCount = useStore((state) => state.rows.length)

  const handleClear = () => {
    if (rowCount === 0) {
      alert('No data to clear')
      return
    }

    const confirmed = confirm(
      `⚠️  This will delete all loaded data (${rowCount} rows) and snapshots.\n\n` +
      `You'll need to re-import your files.\n\n` +
      `Continue?`
    )

    if (confirmed) {
      clearAllData()
      alert('✓ All data cleared. Ready for fresh import.')
    }
  }

  return (
    <Button 
      variant="outline" 
      onClick={handleClear}
      disabled={rowCount === 0}
      title="Clear all data and start fresh"
    >
      <Trash2 className="h-4 w-4 mr-2" />
      Clear All
    </Button>
  )
}

