import { useStore } from '@/state/store'
import { useSelectedRow } from '@/state/selectors'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ThermometerCell } from '@/components/table/ThermometerCell'
import { StatusSelect } from '@/components/table/StatusSelect'
import { RejectionSelect } from '@/components/table/RejectionSelect'
import { exportRowDetail } from '@/lib/excel'
import { formatDate, formatNumber } from '@/lib/utils'
import { X, Download, AlertCircle } from 'lucide-react'

export function DetailDrawer() {
  const drawerOpen = useStore((state) => state.ui.drawerOpen)
  const closeDrawer = useStore((state) => state.closeDrawer)
  const updateRow = useStore((state) => state.updateRow)
  const row = useSelectedRow()

  if (!drawerOpen || !row) return null

  const handleExport = () => {
    exportRowDetail(row)
  }

  const handleMarkActioned = () => {
    updateRow(row.ExceptionId, { CurrentStatus: 'Actioned' })
  }

  const handleEscalate = () => {
    updateRow(row.ExceptionId, { CurrentStatus: 'Escalated / Pending' })
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 z-40"
        onClick={closeDrawer}
      />

      {/* Drawer */}
      <div className="fixed right-0 top-0 bottom-0 w-full max-w-2xl bg-background z-50 shadow-xl overflow-y-auto">
        <div className="sticky top-0 bg-background border-b p-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">Exception Details</h2>
          <Button variant="ghost" size="icon" onClick={closeDrawer}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {/* Header Badges */}
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">Material: {row.Material}</Badge>
            <Badge variant="outline">Vendor: {row.VendorName}</Badge>
            <Badge variant="outline">Planner: {row.Planner}</Badge>
            {row.ActionableFlag && <Badge variant="success">Actionable</Badge>}
          </div>

          {/* Key Fields */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground">Exception ID</label>
              <div className="text-sm">{row.ExceptionId}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Plant</label>
              <div className="text-sm">{row.Plant}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Material Name</label>
              <div className="text-sm">{row.MaterialName || '—'}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Account Specialist</label>
              <div className="text-sm">{row.AccountSpecialist}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Value Stream</label>
              <div className="text-sm">{row.ValueStream || '—'}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Business Unit</label>
              <div className="text-sm">{row.BusinessUnit || '—'}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Units Excess</label>
              <div className="text-sm">{formatNumber(row.UnitsExcess)}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Days of Inventory</label>
              <div className="text-sm">
                {row.DaysOfInventoryOnHand !== null ? formatNumber(row.DaysOfInventoryOnHand) : '—'}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Push Out Date</label>
              <div className="text-sm">{formatDate(row.PushOutToDate)}</div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Time Fence Days</label>
              <div className="text-sm">
                {row.TimeFenceDays !== null ? `${row.TimeFenceDays}d` : '—'}
              </div>
            </div>
            <div className="col-span-2">
              <label className="text-sm font-medium text-muted-foreground">
                Existing Categorization (PN EM Code Desc)
              </label>
              <div className="text-sm">{row.ExistingCategorization || '—'}</div>
            </div>
            <div className="col-span-2">
              <label className="text-sm font-medium text-muted-foreground">Constraints</label>
              <div className="text-sm">{row.Constraints.join('; ') || '—'}</div>
            </div>
          </div>

          {/* Large Bar Chart */}
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Value Breakdown
            </label>
            <div className="scale-125 origin-left">
              <ThermometerCell
                excessValue={row.ExcessValue}
                actionedValue={row.ActionedValue}
                thermometerPct={row.ThermometerPct}
              />
            </div>
          </div>

          {/* Inline Editing */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                Current Status
              </label>
              <StatusSelect exceptionId={row.ExceptionId} currentStatus={row.CurrentStatus} />
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                Rejection Cause
              </label>
              <RejectionSelect exceptionId={row.ExceptionId} currentRejectionCause={row.RejectionCause} />
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                Action Category
              </label>
              <input
                type="text"
                value={row.ActionCategory || ''}
                onChange={(e) =>
                  updateRow(row.ExceptionId, { ActionCategory: e.target.value })
                }
                className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Enter category..."
              />
            </div>
            <div className="col-span-2">
              <label className="text-sm font-medium text-muted-foreground mb-2 block">
                Notes
              </label>
              <textarea
                value={row.Notes || ''}
                onChange={(e) => updateRow(row.ExceptionId, { Notes: e.target.value })}
                className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-primary"
                rows={3}
                placeholder="Add notes..."
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button onClick={handleExport} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Detail
            </Button>
            <Button onClick={handleMarkActioned}>Mark Actioned</Button>
            <Button onClick={handleEscalate} variant="destructive">
              <AlertCircle className="h-4 w-4 mr-2" />
              Escalate
            </Button>
          </div>

          {/* History Timeline */}
          {row.ChangeLog && row.ChangeLog.length > 0 && (
            <div>
              <h3 className="text-sm font-medium mb-3">Change History</h3>
              <div className="space-y-2">
                {row.ChangeLog.slice()
                  .reverse()
                  .map((entry, idx) => (
                    <div key={idx} className="flex gap-3 text-xs border-l-2 border-primary pl-3 py-1">
                      <div className="flex-1">
                        <div className="font-medium">{entry.user}</div>
                        <div className="text-muted-foreground">
                          Changed {entry.field}: {entry.oldValue || '—'} → {entry.newValue || '—'}
                        </div>
                      </div>
                      <div className="text-muted-foreground">
                        {new Date(entry.timestamp).toLocaleString()}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  )
}

