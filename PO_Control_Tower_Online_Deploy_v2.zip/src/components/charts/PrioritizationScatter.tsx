import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useTableRows } from '@/state/selectors'
import { useStore } from '@/state/store'
import { ExceptionRow, GroupedRow } from '@/types'
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Label, Cell } from 'recharts'
import { formatCurrency, formatNumber } from '@/lib/utils'
import { useMemo } from 'react'

interface ScatterDataPoint {
  name: string
  dio: number
  excessValue: number
  priority: 'low' | 'medium' | 'high'
  exceptionId?: string // For individual items
  groupKey?: string // For groups
}

export function PrioritizationScatter() {
  const tableRows = useTableRows()
  const groupingMode = useStore((state) => state.ui.groupingMode)
  const openDrawer = useStore((state) => state.openDrawer)

  const scatterData = useMemo(() => {
    let dataPoints: ScatterDataPoint[] = []

    if (groupingMode === 'none') {
      // Individual rows - take top 100 by excess value
      const topRows = (tableRows as ExceptionRow[])
        .filter(row => row.DaysOfInventoryOnHand !== null && row.DaysOfInventoryOnHand > 0)
        .sort((a, b) => b.ExcessValue - a.ExcessValue)
        .slice(0, 100)

      dataPoints = topRows.map(row => ({
        name: `${row.Material}${row.MaterialName ? ' - ' + row.MaterialName : ''}`,
        dio: row.DaysOfInventoryOnHand!,
        excessValue: row.ExcessValue,
        priority: getPriority(row.ExcessValue, row.DaysOfInventoryOnHand!),
        exceptionId: row.ExceptionId,
      }))
    } else {
      // Grouped rows - take top 100 groups by total excess value
      const topGroups = (tableRows as GroupedRow[])
        .slice(0, 100)

      topGroups.forEach(group => {
        // For each group, calculate weighted average DIO
        const totalValue = group.totalExcessValue
        let weightedDIO = 0
        let totalWeight = 0

        group.rows.forEach(row => {
          if (row.DaysOfInventoryOnHand !== null && row.DaysOfInventoryOnHand > 0) {
            weightedDIO += row.DaysOfInventoryOnHand * row.ExcessValue
            totalWeight += row.ExcessValue
          }
        })

        const avgDIO = totalWeight > 0 ? weightedDIO / totalWeight : 0

        if (avgDIO > 0) {
          dataPoints.push({
            name: group.groupLabel,
            dio: avgDIO,
            excessValue: totalValue,
            priority: getPriority(totalValue, avgDIO),
            groupKey: group.groupKey,
          })
        }
      })
    }

    return dataPoints
  }, [tableRows, groupingMode])

  const handleDotClick = (data: ScatterDataPoint) => {
    // If it's an individual item, open the drawer
    if (data.exceptionId) {
      openDrawer(data.exceptionId)
    }
    // For grouped items, you could expand the group or show a summary
    // For now, just log it
    if (data.groupKey) {
      console.log('Clicked group:', data.groupKey)
    }
  }

  // Split data by priority for separate scatter series
  const highPriorityData = scatterData.filter(d => d.priority === 'high')
  const mediumPriorityData = scatterData.filter(d => d.priority === 'medium')
  const lowPriorityData = scatterData.filter(d => d.priority === 'low')

  if (scatterData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Excess Prioritization by DIO and Excess $</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] flex items-center justify-center text-muted-foreground">
            No data with DIO values available. Upload inventory data to calculate DIO.
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold">
          Excess Prioritization by DIO and Excess $
        </CardTitle>
        <p className="text-xs text-muted-foreground mt-1">
          Top {scatterData.length} {groupingMode !== 'none' ? 'groups' : 'items'} • Click a dot to view details
        </p>
      </CardHeader>
      <CardContent className="pt-2">
        <ResponsiveContainer width="100%" height={340}>
          <ScatterChart margin={{ top: 10, right: 20, bottom: 35, left: 70 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              type="number" 
              dataKey="dio" 
              name="DIO"
              tick={{ fontSize: 12 }}
              tickFormatter={(val) => Math.round(val).toString()}
              domain={[0, 'auto']}
            >
              <Label 
                value="Current DIO (days)" 
                position="bottom" 
                offset={15}
                style={{ fontSize: 12, fill: '#6b7280' }}
              />
            </XAxis>
            <YAxis 
              type="number" 
              dataKey="excessValue" 
              name="Excess $"
              tick={{ fontSize: 12 }}
              tickFormatter={(val) => {
                if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`
                if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`
                return formatCurrency(val)
              }}
              domain={[0, 'auto']}
            >
              <Label 
                value="Excess $" 
                angle={-90} 
                position="insideLeft"
                offset={10}
                style={{ fontSize: 12, fill: '#6b7280', textAnchor: 'middle' }}
              />
            </YAxis>
            <Tooltip
              cursor={{ strokeDasharray: '3 3' }}
              content={({ active, payload }) => {
                if (!active || !payload || !payload.length) return null
                const data = payload[0].payload as ScatterDataPoint
                return (
                  <div className="bg-white border border-gray-200 rounded-lg shadow-lg p-3 max-w-xs">
                    <div className="font-semibold text-sm mb-2 truncate" title={data.name}>
                      {data.name}
                    </div>
                    <div className="text-xs space-y-1.5">
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">Excess:</span>
                        <span className="font-medium">{formatCurrency(data.excessValue)}</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">DIO:</span>
                        <span className="font-medium">{formatNumber(data.dio)} days</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">Priority:</span>
                        <span className={`font-medium capitalize ${
                          data.priority === 'high' ? 'text-blue-900' :
                          data.priority === 'medium' ? 'text-blue-600' :
                          'text-gray-500'
                        }`}>
                          {data.priority}
                        </span>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground mt-2 italic">
                      Click to view details
                    </div>
                  </div>
                )
              }}
            />

            {/* Low priority (light gray) */}
            <Scatter 
              name="Low priority" 
              data={lowPriorityData}
              fill="#9ca3af"
              shape="circle"
              onClick={(data) => handleDotClick(data)}
              style={{ cursor: 'pointer' }}
            >
              {lowPriorityData.map((_entry, index) => (
                <Cell key={`cell-low-${index}`} />
              ))}
            </Scatter>
            
            {/* Medium priority (blue) */}
            <Scatter 
              name="Medium priority" 
              data={mediumPriorityData}
              fill="#60a5fa"
              shape="circle"
              onClick={(data) => handleDotClick(data)}
              style={{ cursor: 'pointer' }}
            >
              {mediumPriorityData.map((_entry, index) => (
                <Cell key={`cell-medium-${index}`} />
              ))}
            </Scatter>
            
            {/* High priority (dark navy) */}
            <Scatter 
              name="High priority" 
              data={highPriorityData}
              fill="#1e40af"
              shape="circle"
              onClick={(data) => handleDotClick(data)}
              style={{ cursor: 'pointer' }}
            >
              {highPriorityData.map((_entry, index) => (
                <Cell key={`cell-high-${index}`} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
        
        {/* Legend */}
        <div className="flex items-center justify-center gap-6 text-xs mt-4 pb-1">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 bg-[#1e40af] rounded-full"></div>
            <span className="text-muted-foreground">High priority</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 bg-[#60a5fa] rounded-full"></div>
            <span className="text-muted-foreground">Medium priority</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 bg-[#9ca3af] rounded-full"></div>
            <span className="text-muted-foreground">Low priority</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

/**
 * Determine priority based on Excess $ and DIO
 * High priority: High excess $ and/or low DIO
 * Low priority: Low excess $ and high DIO
 */
function getPriority(excessValue: number, dio: number): 'low' | 'medium' | 'high' {
  // Normalize scores (0-100)
  const valueScore = Math.min(100, (excessValue / 100000) * 100) // $100k = max
  const dioScore = Math.max(0, 100 - (dio / 365) * 100) // Lower DIO = higher score
  
  const combinedScore = (valueScore * 0.7 + dioScore * 0.3) // Weight value more heavily

  if (combinedScore >= 70) return 'high'
  if (combinedScore >= 40) return 'medium'
  return 'low'
}

