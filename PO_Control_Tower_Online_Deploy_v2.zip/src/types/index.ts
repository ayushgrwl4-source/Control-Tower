// ============================================================================
// Core Data Types
// ============================================================================

export interface AuditEntry {
  timestamp: string
  user: string
  field: string
  oldValue: string | null
  newValue: string | null
}

export interface ExceptionRow {
  // Mapped from Excel (required)
  Material: string
  MaterialName?: string | null
  VendorName: string
  Planner: string
  AccountSpecialist: string
  Plant: string
  UnitsExcess: number
  ExcessValue: number
  PushOutToDate: string | null
  TimeFenceDays: number | null
  Constraints: string[] // combined from multiple constraint columns
  ActionCategory: string | null
  CurrentStatus: string
  ExistingCategorization: string | null // PN EM Code Desc
  ValueStream: string | null // Engine Family
  BusinessUnit: string | null // Buyer Group
  DaysOfInventoryOnHand: number | null

  // Optional auto-detected columns
  ExceptionDate?: string | null
  Currency?: string | null
  DocNumber?: string | null
  Item?: string | null
  SchedLine?: string | null
  LeadTime?: number | null
  SumOfDaysToPush?: number | null
  DeliveryDate?: string | null
  Confirmed?: string | null
  ASNNumber?: string | null
  Notes?: string | null
  RejectionCause?: string | null // RULE 2.4: Planner rejection reason

  // Snapshot metadata (RULE 1.1, 1.3)
  SnapshotDate: string // ISO-8601 date string identifying this snapshot

  // Derived fields (computed by app)
  ExceptionId: string // composite or fallback GUID
  PriorityScore: number
  ActionableFlag: boolean
  ActionedValue: number // cumulative dollars actioned
  ThermometerPct: number // ActionedValue / ExcessValue (0-100)

  // Audit
  LastUpdatedBy?: string | null
  LastUpdatedAt?: string | null
  ChangeLog: AuditEntry[]
}

// ============================================================================
// Rules & Configuration
// ============================================================================

export interface ActionableRules {
  denyExact: string[]
  allowExact: string[]
  fallback: 'allow_if_not_denied' | 'deny_if_not_allowed'
}

export interface RulesConfig {
  rulesVersion: number
  sourceField: string // e.g., "PN EM Code Desc"
  actionedStatuses: string[]
  actionableLogic: 'custom' | 'simple'
  actionable: ActionableRules
  additionalClauses?: unknown[] // reserved for future thresholds
}

export interface HeaderMap {
  Material: string | null
  MaterialName: string | null
  VendorName: string | null
  Planner: string | null
  AccountSpecialist: string | null
  Plant: string | null
  UnitsExcess: string | null
  ExcessValue: string | null
  PushOutToDate: string | null
  TimeFenceDays: string | null
  Constraints: string[] | null
  ActionCategory: string | null
  CurrentStatus: string | null
  ExistingCategorization: string | null
  ValueStream: string | null
  BusinessUnit: string | null
  DaysOfInventoryOnHand: string | null
}

// ============================================================================
// UI State Types
// ============================================================================

export type GroupingMode = 'none' | 'part' | 'vendor' | 'valueStream' | 'businessUnit' | 'planner' | 'accountSpecialist'

export interface FilterState {
  search: string
  planners: string[]
  vendors: string[]
  plants: string[]
  statuses: string[]
  accountSpecialists: string[]
  actionableOnly: boolean
  valueRange: [number, number] | null
  doiRange: [number, number] | null
  dateRange: [Date, Date] | null
  weekStart: Date
  weekEnd: Date
  riskDate: Date | null
  baseCurrency: string
  snapshotDates: string[] // RULE 5.1: Multi-select snapshot date filter
}

export interface UIState {
  groupingMode: GroupingMode
  drawerOpen: boolean
  selectedRowId: string | null
  uploadModalOpen: boolean
  settingsModalOpen: boolean
}

// ============================================================================
// KPI & Burndown Types
// ============================================================================

export interface KPIData {
  totalExcess: number
  actionableExcess: number
  weeklyClearancePct: number
  overallBurnPct: number
  dollarsActionedThisWeek: number
  newActionableDollarsThisWeek: number
  openingActionableBacklog: number
  onTrack: boolean
  currencyMixed: boolean
  currencies: string[]
}

export interface BurndownPoint {
  day: number
  date: string
  target: number
  actual: number | null
}

// ============================================================================
// Table Grouping
// ============================================================================

export interface GroupedRow {
  isGroup: true
  groupKey: string
  groupLabel: string
  rows: ExceptionRow[]
  totalExcessValue: number
  totalUnitsExcess: number
  totalActionedValue: number
  thermometerPct: number
}

export type TableRow = ExceptionRow | GroupedRow

// ============================================================================
// Import/Export
// ============================================================================

export interface ImportResult {
  rows: ExceptionRow[]
  warnings: string[]
  detectedHeaders: string[]
  snapshotDates?: string[] // Detected snapshot dates from multi-sheet or date column
}

// RULE 1.1: Snapshot metadata
export interface SnapshotMetadata {
  snapshotDate: string // ISO-8601 date string
  importedAt: string // Timestamp when snapshot was imported
  rowCount: number // Number of rows in this snapshot
  fileName: string // Original filename
}

// RULE 8.1: Multi-sheet Excel parsing result
export interface MultiSheetParseResult {
  sheets: Array<{
    sheetName: string
    snapshotDate: string | null
    headers: string[]
    data: any[]
  }>
}

export interface ExportOptions {
  filename: string
  includeFilters: boolean
  selectedOnly: boolean
}


