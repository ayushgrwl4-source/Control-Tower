import { ExceptionRow, GroupedRow, TableRow } from '@/types'
import { useStore } from './store'
import { useMemo } from 'react'
import { calculateInventoryRisk } from '@/lib/risk'

/**
 * Get filtered rows based on current filter state
 */
export function useFilteredRows(): ExceptionRow[] {
  const rows = useStore((state) => state.rows)
  const filters = useStore((state) => state.filters)

  return useMemo(() => {
    return rows.filter((row) => {
    // Search
    if (filters.search) {
      const searchLower = filters.search.toLowerCase()
      const searchable = [
        row.Material,
        row.MaterialName,
        row.VendorName,
        row.Planner,
        row.ExceptionId,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()
      if (!searchable.includes(searchLower)) return false
    }

    // Planners
    if (filters.planners.length > 0 && !filters.planners.includes(row.Planner)) {
      return false
    }

    // Vendors
    if (filters.vendors.length > 0 && !filters.vendors.includes(row.VendorName)) {
      return false
    }

    // Plants
    if (filters.plants.length > 0 && !filters.plants.includes(row.Plant)) {
      return false
    }

    // Statuses
    if (filters.statuses.length > 0 && !filters.statuses.includes(row.CurrentStatus)) {
      return false
    }

    // Account Specialists
    if (filters.accountSpecialists.length > 0 && !filters.accountSpecialists.includes(row.AccountSpecialist)) {
      return false
    }

    // Actionable only
    if (filters.actionableOnly && !row.ActionableFlag) {
      return false
    }

    // Value range
    if (filters.valueRange) {
      const [min, max] = filters.valueRange
      if (row.ExcessValue < min || row.ExcessValue > max) return false
    }

    // DOI range
    if (filters.doiRange) {
      const [min, max] = filters.doiRange
      if (!row.DaysOfInventoryOnHand) return false
      if (row.DaysOfInventoryOnHand < min || row.DaysOfInventoryOnHand > max) return false
    }

    // Date range
    if (filters.dateRange && row.ExceptionDate) {
      const [start, end] = filters.dateRange
      const exDate = new Date(row.ExceptionDate)
      if (exDate < start || exDate > end) return false
    }

    // RULE 5.1: Snapshot date filter
    if (filters.snapshotDates && filters.snapshotDates.length > 0) {
      if (!filters.snapshotDates.includes(row.SnapshotDate)) {
        return false
      }
    }

      return true
    })
  }, [rows, filters])
}

/**
 * Get grouped rows based on current grouping mode
 */
export function useTableRows(): TableRow[] {
  const filteredRows = useFilteredRows()
  const groupingMode = useStore((state) => state.ui.groupingMode)

  return useMemo(() => {
    if (groupingMode === 'none') {
      // Sort by priority
      return [...filteredRows].sort((a, b) => b.PriorityScore - a.PriorityScore)
    }

    // Group by specified field
    const groupField =
      groupingMode === 'part'
        ? 'Material'
        : groupingMode === 'vendor'
        ? 'VendorName'
        : groupingMode === 'valueStream'
        ? 'ValueStream'
        : groupingMode === 'businessUnit'
        ? 'BusinessUnit'
        : groupingMode === 'planner'
        ? 'Planner'
        : 'AccountSpecialist'

    const groups = new Map<string, ExceptionRow[]>()

    filteredRows.forEach((row) => {
      const key = (row as any)[groupField] || 'Unknown'
      if (!groups.has(key)) {
        groups.set(key, [])
      }
      groups.get(key)!.push(row)
    })

    const result: TableRow[] = []
    groups.forEach((rows, groupKey) => {
      const totalExcessValue = rows.reduce((sum, r) => sum + r.ExcessValue, 0)
      const totalUnitsExcess = rows.reduce((sum, r) => sum + r.UnitsExcess, 0)
      const totalActionedValue = rows.reduce((sum, r) => sum + r.ActionedValue, 0)
      const thermometerPct = totalExcessValue > 0 ? (totalActionedValue / totalExcessValue) * 100 : 0

      const groupedRow: GroupedRow = {
        isGroup: true,
        groupKey,
        groupLabel: groupKey,
        rows: rows.sort((a, b) => b.PriorityScore - a.PriorityScore),
        totalExcessValue,
        totalUnitsExcess,
        totalActionedValue,
        thermometerPct,
      }

      result.push(groupedRow)
    })

    // Sort groups by total excess value
    return result.sort((a, b) => {
      const aVal = (a as GroupedRow).totalExcessValue
      const bVal = (b as GroupedRow).totalExcessValue
      return bVal - aVal
    })
  }, [filteredRows, groupingMode])
}

/**
 * Get unique values for filter dropdowns
 */
export function useFilterOptions() {
  const rows = useStore((state) => state.rows)

  return useMemo(() => {
    const planners = [...new Set(rows.map((r) => r.Planner).filter(Boolean))].sort()
    const vendors = [...new Set(rows.map((r) => r.VendorName).filter(Boolean))].sort()
    const plants = [...new Set(rows.map((r) => r.Plant).filter(Boolean))].sort()
    const statuses = [...new Set(rows.map((r) => r.CurrentStatus).filter(Boolean))].sort()
    const accountSpecialists = [...new Set(rows.map((r) => r.AccountSpecialist).filter(Boolean))].sort()
    const snapshotDates = [...new Set(rows.map((r) => r.SnapshotDate).filter(Boolean))].sort()

    return { planners, vendors, plants, statuses, accountSpecialists, snapshotDates }
  }, [rows])
}

/**
 * Get the currently selected row for the drawer
 */
export function useSelectedRow(): ExceptionRow | null {
  const rows = useStore((state) => state.rows)
  const selectedRowId = useStore((state) => state.ui.selectedRowId)

  if (!selectedRowId) return null
  return rows.find((r) => r.ExceptionId === selectedRowId) || null
}

/**
 * Get inventory risk metrics for the selected date
 */
export function useInventoryRisk() {
  const rows = useStore((state) => state.rows)
  const riskDate = useStore((state) => state.filters.riskDate)

  return useMemo(() => {
    return calculateInventoryRisk(rows, riskDate)
  }, [rows, riskDate])
}


