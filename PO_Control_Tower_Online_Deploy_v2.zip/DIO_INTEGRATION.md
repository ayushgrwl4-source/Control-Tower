# Days of Inventory On Hand (DIO) Integration

## Overview

The app can now import inventory data and automatically calculate DIO for each exception by joining on Material Number + Plant.

---

## How It Works

### Data Join
- **Exceptions data**: Material Number + Plant
- **Inventory data**: material_number + plant
- **Join key**: `${MaterialNumber}-${Plant}` (concatenated)

### DIO Calculation

**Formula**:
```
pieces_per_day = next_1year_requirements / working_days
DIO = unrestricted_stock_quantity / pieces_per_day
```

**Where**:
- `next_1year_requirements` = Annual demand/consumption (pieces/year)
- `working_days` = Working days per year (default: 252)
- `unrestricted_stock_quantity` = Current inventory on hand (pieces)
- `DIO` = Days of inventory remaining at current consumption rate

---

## How to Use

### 1. Upload Inventory Data

Click the **"Import DIO Data"** button in the top right (database icon).

### 2. Select Your Inventory File

The file should contain:
- ✅ `material_number` (or "Material Number")
- ✅ `plant` (or "Plant")
- ✅ `unrestricted_stock_quantity` (current inventory)
- ✅ `next_1year_requirements` (annual demand) **← REQUIRED for DIO calculation**
- ⚙️ `working_days` (optional, defaults to 252)

### 3. DIO Auto-Calculated

Once uploaded:
- App joins inventory data with exceptions by Material-Plant key
- DIO is calculated for each matching exception
- DOI column in the table updates automatically
- Priority score recalculates (considers DIO for ranking)

---

## Current Inventory File Status

### File Loaded
✅ **102,167 inventory records** from PWC inventory snapshot

### Available Columns
The current file (`(Subset) PWC inventory_Sep28Snapshot.xlsx`) contains:
- ✅ material_number
- ✅ plant  
- ✅ unrestricted_stock_quantity
- ✅ total_stock_quantity
- ✅ safety_stock_quantity
- ❌ **next_1year_requirements** (MISSING)
- ❌ working_days (MISSING)

### Impact
⚠️ **DIO cannot be calculated** without the `next_1year_requirements` column.

The app will:
- Load the inventory data
- Create Material-Plant mappings
- Show a warning that DIO calculation requires requirements data
- Keep existing DIO values from the exceptions file (if any)

---

## To Calculate DIO

You need **one of these solutions**:

### Option 1: Use a Different Inventory File
Provide an inventory file that includes annual requirements:
- Column name: `next_1year_requirements` or `annual_requirements`
- Contains yearly demand/consumption in pieces

### Option 2: Add Requirements Data
Add a column to your current inventory file:
- Name it `next_1year_requirements`
- Populate with annual demand for each Material-Plant combination
- Re-upload the file

### Option 3: Use Existing DIO (If Available)
If your exceptions file already has DIO values in the "Days of Inventory" column:
- Those values will be preserved
- No inventory file upload needed

---

## Example Inventory File Format

```csv
material_number,plant,unrestricted_stock_quantity,next_1year_requirements,working_days
MAT-1001,Plant-001,5000,60000,252
MAT-1002,Plant-001,2500,30000,252
MAT-1003,Plant-002,1000,12000,252
```

**DIO Calculation Example**:
- Material: MAT-1001
- Plant: Plant-001
- Stock on hand: 5,000 pieces
- Annual requirement: 60,000 pieces
- Working days: 252
- **pieces_per_day** = 60,000 / 252 = 238 pieces/day
- **DIO** = 5,000 / 238 = **21 days**

---

## Files Modified

### New Files Created:
1. `src/lib/inventory.ts` - Inventory parsing and DIO calculation
2. `src/components/upload/InventoryUploadButton.tsx` - Upload button component
3. `public/inventory-data.xlsx` - Auto-loaded inventory file (102k records)

### Modified Files:
1. `src/state/store.ts` - Added inventoryMap state and DIO recalculation
2. `src/pages/Dashboard.tsx` - Added inventory auto-load and button
3. `src/components/table/ActionBoard.tsx` - Removed Plant and Time Fence columns

---

## Features

### ✅ What Works Now:
- Upload inventory data file
- Join by Material-Plant key
- Store 100k+ inventory records efficiently
- Button shows count of loaded records
- Auto-loads inventory on startup (if file exists in public/)
- Warns user if requirements column is missing

### ⚠️ What Needs Data:
- DIO calculation requires `next_1year_requirements` column
- Current file doesn't have this column
- User needs to provide file with annual requirements

---

## Next Steps

**To get DIO working**:

1. Check if you have a different inventory file with annual requirements/demand
2. OR add a requirements column to the existing file
3. Upload the file using "Import DIO Data" button
4. DIO will auto-calculate for all Material-Plant combinations

---

## Button Location

**Top right header**:
```
[📅 Risk Date] | [💾 Import DIO Data] [📄 Load Sample] [📤 Import] [📥 Export]
```

- Shows "Import DIO Data" when no data loaded
- Shows "DIO Data (102,167)" when data is loaded
- Blue background when data is active

---

**The infrastructure is ready - just need requirements data to complete DIO calculations!** 📊



