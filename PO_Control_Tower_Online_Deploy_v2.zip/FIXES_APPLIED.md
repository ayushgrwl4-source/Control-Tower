# Recent Fixes Applied

## 1. ✅ Status Column Width Fixed
**Issue**: In the table view, the Status column was too narrow to see the dropdown.

**Fix**: Added `size: 180` to the Status column definition, making it wide enough to display the full status dropdown comfortably.

**Location**: `src/components/table/ActionBoard.tsx`

---

## 2. ✅ Push Out Date - Wrong Year Fixed
**Issue**: The "Push Out Date" column was showing the wrong year (likely 1900 or 1970).

**Root Cause**: Excel stores dates as serial numbers (days since 1900-01-01), but the app was treating them as strings or not parsing them correctly.

**Fix**: 
- Added `parseExcelDate()` function to properly handle Excel date serial numbers
- Converts Excel serial dates to ISO date strings (YYYY-MM-DD)
- Handles Excel's 1900 leap year bug
- Also works with date strings and Date objects

**Also Fixed**:
- ExceptionDate (the "Date" column)
- DeliveryDate (the "Delv. Date" column)

**Location**: `src/lib/excel.ts`

**How It Works**:
```typescript
// Excel date serial number (e.g., 45321) 
// → JavaScript Date → ISO string (2024-01-15)
```

---

## 3. ✅ Added "PN EM Code Desc" Column
**Issue**: In Vendor view (and all views), the "PN EM Code Desc" column was missing.

**Fix**: 
- Added new column for `ExistingCategorization` (which maps to "PN EM Code Desc")
- Column appears after Status column
- Shows the categorization value or "—" if empty
- Width set to 150px

**Location**: `src/components/table/ActionBoard.tsx`

**Column Order Now**:
1. Value (Bar Chart)
2. Material
3. Vendor
4. Planner
5. Plant
6. Units Excess
7. DOI
8. Action Category
9. **Status** (wider now - 180px)
10. **PN EM Code Desc** ← NEW!
11. Push Out Date (fixed year)
12. Time Fence
13. Constraints

---

## To See the Changes

**Refresh your browser** - the app will automatically reload with:
- ✅ Wider Status column (can now see full dropdown)
- ✅ Correct years in Push Out Date column
- ✅ New "PN EM Code Desc" column visible in all views

---

## Technical Details

### Date Parsing Logic
The new `parseExcelDate()` function handles three input types:

1. **String dates**: "2024-01-15" → "2024-01-15"
2. **Excel serial numbers**: 45321 → "2024-01-15"
3. **Date objects**: Date(2024,0,15) → "2024-01-15"

Excel serial dates calculation:
```
Excel stores dates as: Days since 1900-01-01
Adjustment needed: -2 days (for Excel's 1900 leap year bug)
Formula: new Date(1900-01-01) + (serial - 2) days
```

---

## Files Modified

1. `src/components/table/ActionBoard.tsx`
   - Widened Status column
   - Added PN EM Code Desc column

2. `src/lib/excel.ts`
   - Added `parseExcelDate()` function
   - Applied date parsing to PushOutToDate, ExceptionDate, DeliveryDate

---

All changes are backward compatible and build successfully! ✅



