# Getting Started - New Company Setup

This is a clean installation of the PO Control Tower webapp ready for your company's data.

## Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

## Setup Steps

### 1. Install Dependencies

Open a terminal in this directory and run:

```bash
npm install
```

This will install all required packages (React, TypeScript, Vite, etc.)

### 2. Prepare Your Data

The app expects Excel files with purchase order exception data. You have two options:

**Option A: Import via UI (Recommended)**
- Start the app (see step 3)
- Click the "Import Excel" button
- Select your company's Excel file

**Option B: Place in data folder**
- Copy your Excel file(s) to the `data/` directory
- Then import via the UI

### 3. Start the Development Server

```bash
npm run dev
```

The app will start at `http://localhost:5173`

### 4. Configure for Your Data

#### Update Header Mapping

If your Excel columns have different names, edit `public/default-header-map.json`:

```json
{
  "Material Number": "MaterialNumber",
  "Your Column Name": "MaterialNumber",
  ...
}
```

Map your Excel headers (left) to internal field names (right).

#### Configure Business Rules

Edit `public/default-rules.json` to define:
- Which statuses count as "actioned"
- Which items are actionable based on your business logic

```json
{
  "actionedStatuses": ["Actioned", "Approved", "Closed"],
  "actionable": {
    "denyExact": ["Do Not Action"],
    "allowExact": ["Negotiation"],
    "fallback": "allow_if_not_denied"
  }
}
```

### 5. Customize Branding (Optional)

- **App Title**: Edit `index.html` (line with `<title>`)
- **Colors**: Edit `tailwind.config.js` to match your brand
- **Package Name**: Edit `package.json` name field

## Testing Your Setup

1. Import your Excel data
2. Verify the data appears in the Action Board table
3. Check that KPIs calculate correctly
4. Test filtering and grouping
5. Update a status and verify it's tracked

## Building for Production

When ready to deploy:

```bash
npm run build
```

This creates optimized files in the `dist/` directory.

To preview the production build:

```bash
npm run preview
```

## Data Schema Reference

Your Excel file should include these columns (customizable via header mapping):

### Required:
- Material Number
- Vendor Name  
- Material Planner
- Plant
- Outstanding Quantity
- Remaining Opportunity (dollars)
- Status

### Optional but Recommended:
- Account Specialist
- Reschedule Date
- Contractual Firm Zone
- PN EM Code Description (for actionability rules)
- Engine Family / Buyer Group (for grouping)
- Date

## Troubleshooting

**Data not loading?**
- Check browser console for errors
- Verify Excel column names match your header mapping
- Ensure required columns are present

**KPIs showing incorrect values?**
- Review `public/default-rules.json` actionedStatuses
- Check that your Status column values match the configured statuses

**Can't see all columns?**
- The table is horizontally scrollable
- Some columns are hidden by default - use column visibility controls

## Next Steps

1. ✅ Install dependencies (`npm install`)
2. ✅ Start dev server (`npm run dev`)
3. ✅ Import your company's data
4. ✅ Configure header mapping if needed
5. ✅ Customize business rules
6. ✅ Test functionality
7. ✅ Build for production when ready

## Need Help?

Refer to:
- `README.md` - Full documentation
- `simulation_rules.md` - Business logic specification
- Development team - For technical support
