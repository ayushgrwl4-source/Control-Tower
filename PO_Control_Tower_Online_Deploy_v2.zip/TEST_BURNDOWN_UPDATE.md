# How to Test Burndown Chart Updates

## 🔍 **Step-by-Step Testing**

### **1. Open Browser Console**
- Press **F12** (Windows) or **Cmd+Option+J** (Mac)
- Keep console visible while testing

### **2. Refresh the Page**
- Hard refresh: **Ctrl+Shift+R** (Windows) or **Cmd+Shift+R** (Mac)
- This ensures you have the latest code

### **3. Note Starting Values**
Look at the Burndown Metrics box (bottom left of chart):
```
Starting Actionable: $XXX,XXX,XXX
Already Actioned: $0  ← Should start at $0
Remaining: $XXX,XXX,XXX
```

### **4. Change a Status**
1. Find a row in the table (any row)
2. Click the **Status dropdown**
3. Change it to **"Actioned"**

### **5. Watch for Updates**

**In Console**, you should see:
```
Status changed: Not yet assessed → Actioned for DOC10001-10-1
Burndown rendering - dataVersion: 1, Actioned this week: 50000
```

**In Burndown Metrics**, you should see:
```
Already Actioned: $50,000  ← Should increase!
Remaining: $XXX,XXX,XXX    ← Should decrease!
```

**In the Chart**:
- Blue "Actual Remaining" line should move

### **6. Change Another Item**
- Pick a different row
- Change to "Actioned"
- **Watch cumulative effect**:
  - Console shows new dataVersion (2, 3, etc.)
  - "Already Actioned" continues to increase
  - "Remaining" continues to decrease

---

## ✅ **What Should Happen**

Every time you change a status to an "actioned" status:

1. **Console logs appear** immediately
2. **dataVersion increments** (1, 2, 3, ...)
3. **"Already Actioned" increases** by that row's excess value
4. **"Remaining" decreases** by that row's excess value
5. **Chart updates** visually

---

## ❌ **If It's Still Not Working**

### Check These Things:

#### **1. Is the Status in the "Actioned" List?**
The burndown only counts these statuses:
- ✅ "Actioned"
- ✅ "Approved Deviation"  
- ✅ "Escalated / Pending"
- ✅ "Not yet assessed"

Other statuses (like "In Progress", "Blocked") **won't count**.

Try changing to **"Actioned"** specifically.

---

#### **2. Are the Console Logs Appearing?**

**If you see**:
```
Status changed: X → Y for ID
```
But NOT:
```
Burndown rendering - dataVersion: N
```

Then the component isn't re-rendering. Let me know and I'll investigate further.

---

#### **3. Is the ChangeLog Being Created?**

Test the ChangeLog:
1. Change a status
2. Click that row to open detail drawer
3. Scroll down to "Change History"
4. **Should see the change** with today's timestamp

If the change isn't in the ChangeLog, the status update isn't saving properly.

---

#### **4. Is It Counting This Week?**

The burndown only counts changes from **this week** (ISO week).

**Check**:
- What's today's date?
- What's the ISO week range shown in the burndown?

If you're testing on Oct 28, 2025:
- This week = Oct 27 - Nov 2, 2025
- Changes should count

---

#### **5. Hard Refresh Again**

Sometimes the browser caches old JavaScript:
1. **Ctrl+Shift+R** or **Cmd+Shift+R**
2. Or close tab and reopen
3. Check console for any errors

---

## 🐛 **Debugging Commands**

Open browser console and run these:

### Check dataVersion:
```javascript
// Should increment each time you change status
console.log(window.__ZUSTAND_STATE__?.dataVersion)
```

### Check if row has ChangeLog:
```javascript
// After changing status, check the row
// (You'll see this in the detail drawer's Change History section)
```

### Force a refresh:
```javascript
location.reload(true)
```

---

## 📊 **Expected Console Output**

### When Working Correctly:
```
✓ Auto-loaded inventory data for 102167 Material-Plant combinations
✓ Auto-loaded 14207 exceptions from sample data
Burndown rendering - dataVersion: 0, Actioned this week: 0

[User changes status]

Status changed: Not yet assessed → Actioned for DOC10001-10-1
Burndown rendering - dataVersion: 1, Actioned this week: 50000

[User changes another status]

Status changed: In Progress → Actioned for DOC10002-15-2  
Burndown rendering - dataVersion: 2, Actioned this week: 125000
```

---

## 🎯 **What to Look For**

### **Good Signs** ✅:
- ✓ Console shows "Status changed" message
- ✓ Console shows "Burndown rendering" with new dataVersion
- ✓ "Actioned this week" value increases
- ✓ Metrics in burndown box update
- ✓ Change appears in ChangeLog

### **Bad Signs** ❌:
- ✗ No console messages when changing status
- ✗ dataVersion doesn't increment
- ✗ Burndown metrics stay at $0
- ✗ No change in ChangeLog

If you see bad signs, let me know what console messages (if any) you're seeing and I can investigate further.

---

## 🔧 **Advanced Debugging**

If needed, I can add:
- Toast notifications on status change
- Visual flash/highlight on burndown update
- More detailed logging
- State inspector

---

**Try it now!** Refresh your browser, open console, and change a status to "Actioned". You should see immediate updates. 🎯



