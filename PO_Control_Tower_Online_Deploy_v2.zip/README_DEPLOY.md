

## Vercel 404 Troubleshooting

If you see `404: NOT_FOUND` on Vercel:
1. Ensure the build succeeded and `dist/index.html` exists.
2. Make sure your project has this **vercel.json** (already included):
```json
{
  "framework": "vite",
  "installCommand": "npm install",
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "cleanUrls": true,
  "trailingSlash": false,
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```
3. Re-deploy (Upload ZIP or push to Git and import).