# PO Control Tower

A production-quality React + TypeScript single-page application for managing purchase order exceptions. Built for materials planners, account specialists, and executives to track, prioritize, and action excess PO opportunities.

## 🆕 Clean Installation

This is a clean copy of the PO Control Tower webapp, ready for deployment with your company's data.

### Quick Start

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Add your data**:
   - Place your Excel files in the `data/` directory
   - Or use the "Import Excel" button in the app to upload data

3. **Start the development server**:
   ```bash
   npm run dev
   ```
   
   The app will open at `http://localhost:5173`

4. **Build for production**:
   ```bash
   npm run build
   npm run preview
   ```

## Features

- 📊 **KPI Dashboard**: Real-time metrics for total excess, actionable opportunities, and weekly burn rate
- 📈 **Burndown Tracking**: Visual progress against 80% weekly reduction targets
- 🔍 **Advanced Filtering**: Multi-dimensional filtering by planner, vendor, plant, status, and more
- 📋 **Action Board**: Sortable, groupable table with inline status editing and thermometer progress bars
- 📝 **Detail Drawer**: Comprehensive exception details with full edit history and quick actions
- 📤 **Import/Export**: Excel integration for offline workflows and data exchange
- ⚙️ **Configurable Rules**: JSON-based actionability and status configuration

## Tech Stack

- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **State Management**: Zustand
- **UI Components**: Tailwind CSS + shadcn/ui patterns
- **Tables**: TanStack Table v8
- **Charts**: Recharts
- **Excel**: SheetJS (xlsx)
- **Icons**: Lucide React

## Data Schema

The application expects Excel files with the following columns (configurable via header mapping):

### Required Fields
- **Material Number** → Material code
- **Vendor Name** → Supplier name
- **Material Planner** → Planner responsible
- **Account Specialist** → Account owner
- **Plant** → Plant/facility code
- **Outst.Qty.** → Units of excess inventory
- **Remaining Opportunity, $** → Dollar value of excess
- **Status vs. Guideline** → Current exception status

### Optional Fields
- **Resch. Date** → Rescheduled delivery date
- **Contractual Firm Zone (Days)** → Time fence in days
- **PN EM Code Desc** → Categorization for actionability rules
- **Engine Family** → Value stream (proxy)
- **Buyer Group** → Business unit (proxy)
- **Date** → Exception date
- Plus various constraint columns, Doc Number, Item, etc.

### Derived Fields (Computed Automatically)
- **ExceptionId**: Composite key from Doc Number + Item + Sched.Line (or GUID fallback)
- **ActionableFlag**: Determined by rules engine based on `PN EM Code Desc`
- **ActionedValue**: Dollar value actioned (based on status)
- **ThermometerPct**: Progress percentage (ActionedValue / ExcessValue)
- **PriorityScore**: Multi-factor sort key (value, DOI, date)

## Configuration

### Rules Configuration (`public/default-rules.json`)

Controls which exceptions are actionable and which statuses count as "actioned":

```json
{
  "rulesVersion": 2,
  "sourceField": "PN EM Code Desc",
  "actionedStatuses": ["Actioned", "Approved Deviation", "Escalated / Pending", "Not yet assessed"],
  "actionableLogic": "custom",
  "actionable": {
    "denyExact": ["Do Not Action"],
    "allowExact": ["Negotiation"],
    "fallback": "allow_if_not_denied"
  }
}
```

**Logic**:
- Items with `PN EM Code Desc = "Do Not Action"` are **not actionable**
- Items with `PN EM Code Desc = "Negotiation"` are **actionable**
- All others follow the `fallback` rule (default: actionable unless explicitly denied)

### Header Mapping (`public/default-header-map.json`)

Maps Excel column headers to internal field names. Customize this file to match your data source.

### localStorage

User preferences and rules are persisted in `localStorage`:
- `po-control-tower:rules`: Active rules configuration
- `po-control-tower:headerMap`: Current header mapping

## Usage

### 1. Load Data

Click **"Import Excel"** to upload your company's data file.

### 2. Filter & Group

- Use the **search bar** to find exceptions by material, vendor, or planner
- Select **planners, vendors, plants, or statuses** from the filter dropdowns
- Toggle **"Actionable Only"** to focus on items that can be actioned per rules
- **Group by** Part, Vendor, Value Stream, or Business Unit for aggregated views

### 3. Review Exceptions

- Rows are sorted by **Priority Score** (high-value, high-DOI, oldest first)
- The **Thermometer** bar shows actioned progress (green fill = actioned, gray = remaining)
- Click any row to open the **Detail Drawer** for full information

### 4. Update Status

- Use the inline **Status dropdown** in the table or drawer
- Status changes are logged in the **Change History** with timestamp and user
- Statuses in `actionedStatuses` will increment the **% Actioned** KPI

### 5. Track Burndown

- The **Burndown chart** shows weekly progress vs. an 80% reduction target
- **On Track** badge appears when actioned dollars meet or exceed the target line
- Metrics update dynamically as you change statuses

### 6. Export

- **Export Current View**: Downloads filtered/grouped data as Excel
- **Export Detail** (from drawer): Single-row export with all fields
- Re-import exports with offline status updates to sync changes back

## KPIs Explained

### KPI-1: Total Excess
Sum of `ExcessValue` across all exceptions in the current filter.

### KPI-2: Actionable Excess
Sum of `ExcessValue` where `ActionableFlag = true` (per rules).

### KPI-3: % Actioned
- **Weekly Clearance %**: `DollarsActionedThisWeek / NewActionableDollarsThisWeek` (capped at 100%)
- **Overall Burn %**: `DollarsActionedThisWeek / (OpeningBacklog + NewThisWeek)`
- **On Track** if ≥ 80% reduction achieved

Hover over KPI cards for detailed numerators/denominators.

## File Structure

```
po-control-tower/
├── public/
│   ├── default-rules.json          # Rules engine config
│   ├── default-header-map.json     # Excel column mapping
│   └── vite.svg                     # App icon
├── scripts/
│   └── generate-sample-data.js     # Sample data generator
├── src/
│   ├── components/
│   │   ├── ui/                     # Base UI components (Button, Card, Badge)
│   │   ├── kpis/                   # KPI cards and row
│   │   ├── table/                  # Action Board + cells
│   │   ├── drawer/                 # Detail drawer
│   │   ├── burndown/               # Burndown chart
│   │   ├── filters/                # Filters bar
│   │   └── upload/                 # Import/Export buttons
│   ├── lib/
│   │   ├── excel.ts                # Excel parsing & export
│   │   ├── rules.ts                # Actionability logic
│   │   ├── kpi.ts                  # KPI calculations
│   │   └── utils.ts                # Formatters & helpers
│   ├── state/
│   │   ├── store.ts                # Zustand store
│   │   └── selectors.ts            # Derived state selectors
│   ├── types/
│   │   └── index.ts                # TypeScript definitions
│   ├── pages/
│   │   └── Dashboard.tsx           # Main page
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── data/                            # Place your company data here
├── package.json
├── tsconfig.json
├── vite.config.ts
└── tailwind.config.js
```

## Customization for Your Company

1. **Update Header Mapping**: Edit `public/default-header-map.json` to match your Excel column names
2. **Configure Rules**: Edit `public/default-rules.json` to define what's actionable for your business
3. **Brand Colors**: Update `tailwind.config.js` for your company's color scheme
4. **App Title**: Update `index.html` and package name in `package.json`

## Support

For questions or issues, contact the development team.

## License

Proprietary - Internal McKinsey & Company tool
