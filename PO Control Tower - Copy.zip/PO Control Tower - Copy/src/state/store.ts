import { create } from 'zustand'
import {
  ExceptionRow,
  RulesConfig,
  HeaderMap,
  FilterState,
  UIState,
  AuditEntry,
  SnapshotMetadata,
} from '@/types'
import { isActionable, isActionedStatus, loadRulesFromStorage, saveRulesToStorage } from '@/lib/rules'
import { getCurrentWeekBounds } from '@/lib/kpi'
import { InventoryData } from '@/lib/inventory'

interface AppState {
  // Data
  rows: ExceptionRow[]
  rules: RulesConfig
  headerMap: HeaderMap
  currentUser: string
  inventoryMap: Map<string, InventoryData>
  dataVersion: number // Increment to force re-renders
  snapshotMetadata: Map<string, SnapshotMetadata> // RULE 1.1: Track snapshot metadata

  // Filters
  filters: FilterState

  // UI
  ui: UIState

  // Actions
  setRows: (rows: ExceptionRow[], appendMode?: boolean) => void // RULE 1.1: Support appending snapshots
  addSnapshot: (rows: ExceptionRow[], metadata: SnapshotMetadata) => void
  getAvailableSnapshots: () => string[]
  clearAllData: () => void
  updateRow: (exceptionId: string, updates: Partial<ExceptionRow>) => void
  updateRowStatus: (exceptionId: string, newStatus: string, user: string) => void
  updateRowRejectionCause: (exceptionId: string, newCause: string | null, user: string) => void
  setRules: (rules: RulesConfig) => void
  setHeaderMap: (headerMap: HeaderMap) => void
  setFilter: <K extends keyof FilterState>(key: K, value: FilterState[K]) => void
  resetFilters: () => void
  setUI: <K extends keyof UIState>(key: K, value: UIState[K]) => void
  openDrawer: (rowId: string) => void
  closeDrawer: () => void
  recomputeDerived: () => void
  setCurrentUser: (user: string) => void
  setInventoryMap: (map: Map<string, InventoryData>) => void
}

const defaultHeaderMap: HeaderMap = {
  Material: 'Material Number',
  MaterialName: null,
  VendorName: 'Vendor Name',
  Planner: 'Material Planner',
  AccountSpecialist: 'Account Specialist',
  Plant: 'Plant',
  UnitsExcess: 'Outst.Qty.',
  ExcessValue: 'Remaining Opportunity',  // Changed from 'Remaining Opportunity, $'
  PushOutToDate: 'Resch. Date',
  TimeFenceDays: 'Contractual Firm Zone (Days)',
  Constraints: ['Status vs. Guideline', 'Status vs Contracts', 'Guideline vs Contract', 'Contract Exceptions'],
  ActionCategory: null,
  CurrentStatus: 'Status vs. Guideline',
  ExistingCategorization: 'PN EM Code Desc',
  ValueStream: 'Engine Family',
  BusinessUnit: 'Buyer Group',
  DaysOfInventoryOnHand: null,
}

const defaultRules: RulesConfig = {
  rulesVersion: 2,
  sourceField: 'PN EM Code Desc',
  actionedStatuses: ['Actioned', 'Approved Deviation', 'Escalated / Pending', 'Not yet assessed'],
  actionableLogic: 'custom',
  actionable: {
    denyExact: ['Do Not Action'],
    allowExact: ['Negotiation'],
    fallback: 'allow_if_not_denied',
  },
}

const { weekStart, weekEnd } = getCurrentWeekBounds()

const defaultFilters: FilterState = {
  search: '',
  planners: [],
  vendors: [],
  plants: [],
  statuses: [],
  accountSpecialists: [],
  actionableOnly: false,
  valueRange: null,
  doiRange: null,
  dateRange: null,
  weekStart,
  weekEnd,
  riskDate: new Date('2025-12-31'),
  baseCurrency: 'USD',
  snapshotDates: [], // RULE 5.1: Filter by snapshot dates (empty = all)
}

const defaultUI: UIState = {
  groupingMode: 'none',
  drawerOpen: false,
  selectedRowId: null,
  uploadModalOpen: false,
  settingsModalOpen: false,
}

// Save only CHANGED rows to localStorage (much smaller!)
function saveRowsToStorage(rows: ExceptionRow[]): void {
  try {
    // Only save rows that have been modified (have ChangeLog entries)
    const changedRows = rows
      .filter(r => r.ChangeLog && r.ChangeLog.length > 0)
      .map(r => ({
        ExceptionId: r.ExceptionId,
        CurrentStatus: r.CurrentStatus,
        ActionCategory: r.ActionCategory,
        RejectionCause: r.RejectionCause,
        Notes: r.Notes,
        LastUpdatedBy: r.LastUpdatedBy,
        LastUpdatedAt: r.LastUpdatedAt,
        ChangeLog: r.ChangeLog,
      }))
    
    localStorage.setItem('po-control-tower:changes', JSON.stringify(changedRows))
    console.log(`💾 Saved ${changedRows.length} changed rows to localStorage (${(JSON.stringify(changedRows).length / 1024).toFixed(1)}KB)`)
  } catch (error) {
    console.error('Error saving changes to storage:', error)
    if (error instanceof Error && error.message.includes('quota')) {
      alert('Storage quota exceeded! Your changes may not be saved. Try exporting to Excel.')
    }
  }
}

export const useStore = create<AppState>((set, get) => ({
  rows: [],
  rules: loadRulesFromStorage() || defaultRules,
  headerMap: defaultHeaderMap,
  currentUser: 'Current User', // Could be set from login
  inventoryMap: new Map(),
  dataVersion: 0,
  snapshotMetadata: new Map(),

  filters: defaultFilters,
  ui: defaultUI,

  setRows: (rows, appendMode = false) => {
    set((state) => ({ 
      rows: appendMode ? [...state.rows, ...rows] : rows, 
      dataVersion: state.dataVersion + 1 
    }))
    // Recompute in background (don't block)
    setTimeout(() => get().recomputeDerived(), 0)
  },

  addSnapshot: (rows, metadata) => {
    const { snapshotMetadata, filters, rows: existingRows } = get()
    
    // Check if this snapshot already exists (prevent duplicates)
    if (snapshotMetadata.has(metadata.snapshotDate)) {
      console.warn(`⚠️  Snapshot ${metadata.snapshotDate} already loaded, skipping duplicate`)
      return
    }
    
    snapshotMetadata.set(metadata.snapshotDate, metadata)
    
    // Get all snapshot dates including the new one
    const allDates = [...snapshotMetadata.keys()].sort()
    const latestDate = allDates[allDates.length - 1]
    
    // Auto-select latest snapshot for table/scatterplot, keep burndown showing all
    const updatedFilters = {
      ...filters,
      snapshotDates: [latestDate], // Auto-filter to latest snapshot only
    }
    
    set((state) => ({
      rows: [...state.rows, ...rows],
      snapshotMetadata: new Map(snapshotMetadata),
      filters: updatedFilters,
      dataVersion: state.dataVersion + 1,
    }))
    get().recomputeDerived()
  },

  getAvailableSnapshots: () => {
    const snapshots = new Set<string>()
    get().rows.forEach((row) => {
      if (row.SnapshotDate) snapshots.add(row.SnapshotDate)
    })
    return Array.from(snapshots).sort()
  },

  clearAllData: () => {
    // Clear localStorage
    localStorage.removeItem('po-control-tower:changes')
    
    // Reset to empty state
    set({
      rows: [],
      snapshotMetadata: new Map(),
      dataVersion: 0,
      filters: defaultFilters,
    })
    
    console.log('✓ All data cleared')
  },

  updateRow: (exceptionId, updates) => {
    const updatedRows = get().rows.map((row) =>
      row.ExceptionId === exceptionId ? { ...row, ...updates } : row
    )
    set((state) => ({
      rows: updatedRows,
      dataVersion: state.dataVersion + 1,
    }))
    get().recomputeDerived()
    saveRowsToStorage(updatedRows)
  },

  updateRowStatus: (exceptionId, newStatus, user) => {
    const updatedRows = get().rows.map((row) => {
      if (row.ExceptionId !== exceptionId) return row

      const auditEntry: AuditEntry = {
        timestamp: new Date().toISOString(),
        user,
        field: 'CurrentStatus',
        oldValue: row.CurrentStatus,
        newValue: newStatus,
      }

      return {
        ...row,
        CurrentStatus: newStatus,
        LastUpdatedBy: user,
        LastUpdatedAt: new Date().toISOString(),
        ChangeLog: [...row.ChangeLog, auditEntry],
      }
    })
    
    set((state) => ({
      rows: updatedRows,
      dataVersion: state.dataVersion + 1, // Increment to force re-renders
    }))
    get().recomputeDerived()
    saveRowsToStorage(updatedRows)
  },

  updateRowRejectionCause: (exceptionId, newCause, user) => {
    const updatedRows = get().rows.map((row) => {
      if (row.ExceptionId !== exceptionId) return row

      const auditEntry: AuditEntry = {
        timestamp: new Date().toISOString(),
        user,
        field: 'RejectionCause',
        oldValue: row.RejectionCause || null,
        newValue: newCause,
      }

      return {
        ...row,
        RejectionCause: newCause,
        LastUpdatedBy: user,
        LastUpdatedAt: new Date().toISOString(),
        ChangeLog: [...row.ChangeLog, auditEntry],
      }
    })
    
    set((state) => ({
      rows: updatedRows,
      dataVersion: state.dataVersion + 1,
    }))
    saveRowsToStorage(updatedRows)
  },

  setRules: (rules) => {
    set({ rules })
    saveRulesToStorage(rules)
    get().recomputeDerived()
  },

  setHeaderMap: (headerMap) => {
    set({ headerMap })
    localStorage.setItem('po-control-tower:headerMap', JSON.stringify(headerMap))
  },

  setFilter: (key, value) => {
    set((state) => ({
      filters: { ...state.filters, [key]: value },
    }))
  },

  resetFilters: () => {
    const { weekStart, weekEnd } = getCurrentWeekBounds()
    set({
      filters: { ...defaultFilters, weekStart, weekEnd },
    })
  },

  setUI: (key, value) => {
    set((state) => ({
      ui: { ...state.ui, [key]: value },
    }))
  },

  openDrawer: (rowId) => {
    set({ ui: { ...get().ui, drawerOpen: true, selectedRowId: rowId } })
  },

  closeDrawer: () => {
    set({ ui: { ...get().ui, drawerOpen: false, selectedRowId: null } })
  },

  recomputeDerived: () => {
    const { rows, rules, inventoryMap, filters } = get()
    const baseCurrency = filters.baseCurrency || 'USD'

    const updatedRows = rows.map((row) => {
      // Recompute DIO if we have inventory data
      let DaysOfInventoryOnHand = row.DaysOfInventoryOnHand
      if (inventoryMap.size > 0) {
        const key = `${row.Material}-${row.Plant}`
        const inventory = inventoryMap.get(key)
        if (inventory && inventory.next_1year_requirements && inventory.next_1year_requirements > 0) {
          const { next_1year_requirements, unrestricted_stock_quantity, working_days } = inventory
          const pieces_per_day = next_1year_requirements / working_days
          if (pieces_per_day > 0) {
            DaysOfInventoryOnHand = unrestricted_stock_quantity / pieces_per_day
          }
        }
      }

      // Normalize currency (simple approach - assume 1:1 if not USD)
      // In a real system, you'd fetch exchange rates
      let normalizedExcessValue = row.ExcessValue
      if (row.Currency && row.Currency !== baseCurrency) {
        // For now, just flag it - in production you'd convert
        // normalizedExcessValue = row.ExcessValue * exchangeRate
        normalizedExcessValue = row.ExcessValue // Keep as-is for now
      }

      // Compute ActionableFlag
      const ActionableFlag = isActionable(row, rules)

      // Compute ActionedValue: if CurrentStatus is in actionedStatuses, ActionedValue = ExcessValue
      const ActionedValue = isActionedStatus(row.CurrentStatus, rules) ? normalizedExcessValue : 0

      // Compute ThermometerPct
      const ThermometerPct = normalizedExcessValue > 0 ? (ActionedValue / normalizedExcessValue) * 100 : 0

      // Compute PriorityScore (higher is more important)
      // Sort by ExcessValue (desc), then DIO (desc), then ExceptionDate (asc)
      const PriorityScore =
        normalizedExcessValue * 1000000 +
        (DaysOfInventoryOnHand || 0) * 1000 -
        (row.ExceptionDate ? new Date(row.ExceptionDate).getTime() / 100000 : 0)

      return {
        ...row,
        ExcessValue: normalizedExcessValue, // Use normalized value
        DaysOfInventoryOnHand,
        ActionableFlag,
        ActionedValue,
        ThermometerPct,
        PriorityScore,
      }
    })

    set((state) => ({ rows: updatedRows, dataVersion: state.dataVersion + 1 }))
  },

  setCurrentUser: (user) => {
    set({ currentUser: user })
  },

  setInventoryMap: (map) => {
    set({ inventoryMap: map })
    // Recalculate DIO for all existing rows
    get().recomputeDerived()
  },
}))

