import { useStore } from '@/state/store'
import { Calendar } from 'lucide-react'

export function RiskDatePicker() {
  const riskDate = useStore((state) => state.filters.riskDate)
  const setFilter = useStore((state) => state.setFilter)

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value) {
      setFilter('riskDate', new Date(e.target.value))
    } else {
      setFilter('riskDate', null)
    }
  }

  const dateString = riskDate ? riskDate.toISOString().split('T')[0] : ''

  return (
    <div className="flex items-center gap-2 px-3 py-2 border rounded-md bg-background">
      <Calendar className="h-4 w-4 text-muted-foreground" />
      <div className="flex flex-col">
        <label className="text-xs font-medium text-muted-foreground mb-1">
          Inventory Risk Date
        </label>
        <input
          type="date"
          value={dateString}
          onChange={handleDateChange}
          className="text-sm border-none outline-none focus:ring-0 p-0"
          title="Select a date to calculate inventory risk (items scheduled before this date but rescheduled after)"
        />
      </div>
      {riskDate && (
        <button
          onClick={() => setFilter('riskDate', null)}
          className="text-xs text-muted-foreground hover:text-foreground"
          title="Clear risk date"
        >
          ✕
        </button>
      )}
    </div>
  )
}

