import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { useStore } from '@/state/store'
import { parseExcelFileMultiSheet, applyHeaderMap } from '@/lib/excel'
import { isActionable } from '@/lib/rules'
import { Upload } from 'lucide-react'
import { SnapshotMetadata } from '@/types'

// Helper to detect date from filename
function detectDateFromFilename(filename: string): string | null {
  const patterns = [
    /(\d{4})(\d{2})(\d{2})/,  // YYYYMMDD
    /(\d{4})-(\d{2})-(\d{2})/,  // YYYY-MM-DD
    /(\d{2})-(\d{2})-(\d{4})/,  // MM-DD-YYYY
    /(\d{1,2})-(\d{1,2})(?:\s|$)/,  // MM-DD or M-D (like "10-26 ALL LINES")
  ]
  
  for (const pattern of patterns) {
    const match = filename.match(pattern)
    if (match) {
      if (match[1].length === 4) {
        return `${match[1]}-${match[2].padStart(2, '0')}-${match[3].padStart(2, '0')}`
      }
      if (match[3] && match[3].length === 4) {
        return `${match[3]}-${match[1].padStart(2, '0')}-${match[2].padStart(2, '0')}`
      }
      // For MM-DD (assume current year 2025)
      const month = match[1].padStart(2, '0')
      const day = match[2].padStart(2, '0')
      return `2025-${month}-${day}`
    }
  }
  return null
}

export function UploadButton() {
  const [loading, setLoading] = useState(false)
  const addSnapshot = useStore((state) => state.addSnapshot)
  const headerMap = useStore((state) => state.headerMap)
  const rules = useStore((state) => state.rules)

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setLoading(true)
    try {
      // RULE 8.1: Parse multi-sheet Excel file
      const result = await parseExcelFileMultiSheet(file)
      
      let totalImported = 0
      let allWarnings: string[] = []
      
      // RULE 1.2: Try to detect date from filename FIRST
      const filenameDate = detectDateFromFilename(file.name)

      // Process each sheet as a separate snapshot
      for (const sheet of result.sheets) {
        let snapshotDate = sheet.snapshotDate

        // RULE 1.2: Priority order for date detection:
        // 1. Sheet name
        // 2. Filename
        // 3. Data column
        // 4. Prompt user
        if (!snapshotDate && filenameDate) {
          snapshotDate = filenameDate
          console.log(`📅 Using filename date: ${snapshotDate}`)
        }

        if (!snapshotDate) {
          // Try to auto-detect from first row's Date column
          const { snapshotDates } = applyHeaderMap(sheet.data.slice(0, 1), headerMap, sheet.headers)
          if (snapshotDates && snapshotDates.length > 0) {
            snapshotDate = snapshotDates[0]
            console.log(`📅 Using data column date: ${snapshotDate}`)
          } else {
            // Fallback: prompt user for date
            snapshotDate = prompt(
              `Sheet "${sheet.sheetName}" has no detectable date. Enter snapshot date (YYYY-MM-DD):`,
              new Date().toISOString().split('T')[0]
            )
            if (!snapshotDate) {
              console.warn(`Skipping sheet "${sheet.sheetName}" - no snapshot date provided`)
              continue
            }
          }
        }

        // Parse the sheet data with the snapshot date
        const { rows, warnings } = applyHeaderMap(
          sheet.data,
          headerMap,
          sheet.headers,
          snapshotDate
        )

        if (warnings.length > 0) {
          allWarnings.push(`Sheet "${sheet.sheetName}": ${warnings.length} warnings`)
          console.warn(`Sheet "${sheet.sheetName}" warnings:`, warnings)
        }

        // Compute derived fields
        const processedRows = rows.map((row) => ({
          ...row,
          ActionableFlag: isActionable(row, rules),
        }))

        // RULE 1.1: Add snapshot with metadata
        const metadata: SnapshotMetadata = {
          snapshotDate,
          importedAt: new Date().toISOString(),
          rowCount: processedRows.length,
          fileName: file.name,
        }

        addSnapshot(processedRows, metadata)
        totalImported += processedRows.length
      }

      if (allWarnings.length > 0) {
        alert(
          `✓ Imported ${totalImported} exceptions from ${result.sheets.length} snapshot(s)\n\n` +
          `⚠️  Warnings:\n${allWarnings.join('\n')}\n\nCheck console for details.`
        )
      } else {
        alert(`✓ Successfully imported ${totalImported} exceptions from ${result.sheets.length} snapshot(s)`)
      }
    } catch (error) {
      console.error('Import error:', error)
      alert(`Failed to import: ${(error as Error).message}`)
    } finally {
      setLoading(false)
      // Reset the input so the same file can be re-uploaded
      e.target.value = ''
    }
  }

  return (
    <div>
      <input
        type="file"
        accept=".xlsx,.xls"
        onChange={handleFileUpload}
        className="hidden"
        id="excel-upload"
      />
      <label htmlFor="excel-upload" className="cursor-pointer">
        <Button disabled={loading} onClick={() => document.getElementById('excel-upload')?.click()}>
          <Upload className="h-4 w-4 mr-2" />
          {loading ? 'Importing...' : 'Import Excel'}
        </Button>
      </label>
    </div>
  )
}

