import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { useStore } from '@/state/store'
import { parseExcelFile, applyHeaderMap } from '@/lib/excel'
import { isActionable } from '@/lib/rules'
import { FileText } from 'lucide-react'

export function LoadSampleButton() {
  const [loading, setLoading] = useState(false)
  const setRows = useStore((state) => state.setRows)
  const headerMap = useStore((state) => state.headerMap)
  const rules = useStore((state) => state.rules)

  const handleLoadSample = async () => {
    setLoading(true)
    try {
      const response = await fetch('/sample-data.xlsx')
      if (!response.ok) {
        throw new Error('Sample data not found')
      }
      const blob = await response.blob()
      const file = new File([blob], 'sample-data.xlsx', {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      })

      const { headers, data } = await parseExcelFile(file)
      const { rows, warnings } = applyHeaderMap(data, headerMap, headers)

      if (warnings.length > 0) {
        console.warn('Import warnings:', warnings)
      }

      // Compute derived fields
      const processedRows = rows.map((row) => ({
        ...row,
        ActionableFlag: isActionable(row, rules),
      }))

      setRows(processedRows)
      alert(`Loaded ${processedRows.length} sample exceptions`)
    } catch (error) {
      console.error('Load sample error:', error)
      alert(`Failed to load sample: ${(error as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Button variant="secondary" onClick={handleLoadSample} disabled={loading}>
      <FileText className="h-4 w-4 mr-2" />
      {loading ? 'Loading...' : 'Load Sample Data'}
    </Button>
  )
}




