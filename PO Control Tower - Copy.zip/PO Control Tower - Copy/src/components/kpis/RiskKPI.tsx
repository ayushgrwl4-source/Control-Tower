import { useInventoryRisk } from '@/state/selectors'
import { useStore } from '@/state/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatCurrency, formatDate } from '@/lib/utils'
import { AlertTriangle } from 'lucide-react'

export function RiskKPI() {
  const riskDate = useStore((state) => state.filters.riskDate)
  const { riskValue, riskCount } = useInventoryRisk()

  if (!riskDate) return null

  const hasRisk = riskValue > 0

  return (
    <Card className="border-2 border-orange-200 bg-orange-50/50">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-orange-600" />
          Inventory Risk
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-2">
          <div className="text-2xl font-bold text-orange-600">
            {formatCurrency(riskValue)}
          </div>
          {hasRisk && (
            <Badge variant="destructive" className="bg-orange-600">
              {riskCount} items
            </Badge>
          )}
          {!hasRisk && (
            <Badge variant="secondary">No Risk</Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          Risk as of {formatDate(riskDate)}
        </p>
        <p className="text-xs text-muted-foreground mt-2 leading-tight">
          Items scheduled before this date but rescheduled after (creates inventory shortage if not actioned)
        </p>
      </CardContent>
    </Card>
  )
}



