import { useStore } from '@/state/store'
import { memo } from 'react'

interface StatusSelectProps {
  exceptionId: string
  currentStatus: string
}

export const StatusSelect = memo(function StatusSelect({ exceptionId, currentStatus }: StatusSelectProps) {
  const updateRowStatus = useStore((state) => state.updateRowStatus)
  const currentUser = useStore((state) => state.currentUser)

  // All possible statuses (could be enhanced with a dynamic list)
  const allStatuses = [
    'Not yet assessed',
    'Actioned',
    'Approved Deviation',
    'Escalated / Pending',
    'In Progress',
    'Blocked',
    'Do Not Action',
  ]

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = e.target.value
    updateRowStatus(exceptionId, newStatus, currentUser)
    console.log(`Status changed: ${currentStatus} → ${newStatus} for ${exceptionId}`)
  }

  return (
    <select
      value={currentStatus}
      onChange={handleChange}
      className="w-full px-2 py-1 text-sm border rounded focus:outline-none focus:ring-2 focus:ring-primary"
    >
      {allStatuses.map((status) => (
        <option key={status} value={status}>
          {status}
        </option>
      ))}
    </select>
  )
})

