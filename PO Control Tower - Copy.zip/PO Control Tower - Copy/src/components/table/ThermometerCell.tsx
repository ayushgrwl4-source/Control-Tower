import { formatCurrency } from '@/lib/utils'
import { memo } from 'react'

interface ThermometerCellProps {
  excessValue: number
  actionedValue: number
  thermometerPct: number
  maxValue?: number // For relative scaling
}

export const ThermometerCell = memo(function ThermometerCell({ excessValue, actionedValue, thermometerPct, maxValue }: ThermometerCellProps) {
  // Calculate bar width relative to max value if provided
  const barWidth = maxValue && maxValue > 0 ? (excessValue / maxValue) * 100 : 100
  const remainingValue = excessValue - actionedValue
  
  return (
    <div className="w-full min-w-[200px]">
      <div className="flex items-center gap-2 mb-1">
        <div className="flex-1 h-8 relative">
          <div
            className="h-full bg-gray-100 rounded overflow-hidden relative"
            style={{ width: `${Math.min(100, barWidth)}%` }}
            title={`Total: ${formatCurrency(excessValue)} | Actioned: ${formatCurrency(actionedValue)} | Remaining: ${formatCurrency(remainingValue)}`}
          >
            {/* Actioned portion (green) */}
            <div
              className="absolute inset-y-0 left-0 bg-green-500 transition-all"
              style={{ width: `${thermometerPct}%` }}
            />
            {/* Remaining portion (blue) */}
            <div
              className="absolute inset-y-0 bg-blue-500 transition-all"
              style={{ 
                left: `${thermometerPct}%`,
                width: `${100 - thermometerPct}%` 
              }}
            />
          </div>
        </div>
        <div className="text-xs font-medium text-gray-700 whitespace-nowrap min-w-[80px] text-right">
          {formatCurrency(excessValue)}
        </div>
      </div>
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 bg-green-500 rounded-sm"></div>
          <span>{formatCurrency(actionedValue)}</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 bg-blue-500 rounded-sm"></div>
          <span>{formatCurrency(remainingValue)}</span>
        </div>
      </div>
    </div>
  )
})


