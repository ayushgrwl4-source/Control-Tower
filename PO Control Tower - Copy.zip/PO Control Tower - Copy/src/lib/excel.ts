import * as XLSX from 'xlsx'
import { ExceptionRow, HeaderMap, ImportResult, ExportOptions, MultiSheetParseResult } from '@/types'
import { generateGUID } from './utils'

/**
 * RULE 1.2: Detect snapshot date from sheet name
 */
function detectDateFromSheetName(sheetName: string): string | null {
  // Look for date patterns in sheet names
  const patterns = [
    /(\d{4})-(\d{2})-(\d{2})/,  // YYYY-MM-DD
    /(\d{4})(\d{2})(\d{2})/,    // YYYYMMDD
    /(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/,  // M/D/YYYY or MM-DD-YYYY
  ]
  
  for (const pattern of patterns) {
    const match = sheetName.match(pattern)
    if (match) {
      if (match[1].length === 4) {
        // YYYY-MM-DD or YYYYMMDD
        return `${match[1]}-${match[2].padStart(2, '0')}-${match[3].padStart(2, '0')}`
      } else {
        // M/D/YYYY
        return `${match[3]}-${match[1].padStart(2, '0')}-${match[2].padStart(2, '0')}`
      }
    }
  }
  return null
}

/**
 * RULE 8.1: Parse Excel file with multi-sheet support
 * Auto-detects header row (handles files with filter rows at top)
 */
export async function parseExcelFileMultiSheet(file: File): Promise<MultiSheetParseResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: 'array' })
        
        const sheets = workbook.SheetNames.map((sheetName) => {
          const worksheet = workbook.Sheets[sheetName]
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][]
          
          if (jsonData.length < 2) {
            return null
          }

          // Auto-detect header row (look for row with multiple non-null values)
          let headerRowIndex = 0
          for (let i = 0; i < Math.min(5, jsonData.length); i++) {
            const row = jsonData[i]
            const nonNullCount = row.filter(cell => cell !== null && cell !== undefined && cell !== '').length
            
            // If row has many columns, it's likely the header
            if (nonNullCount > 5) {
              headerRowIndex = i
              break
            }
          }

          const headers = jsonData[headerRowIndex].map((h: any) => String(h || '').trim())
          const dataRows = jsonData.slice(headerRowIndex + 1).map((row) => {
            const obj: any = {}
            headers.forEach((header, idx) => {
              obj[header] = row[idx]
            })
            return obj
          })

          const snapshotDate = detectDateFromSheetName(sheetName)

          return {
            sheetName,
            snapshotDate,
            headers,
            data: dataRows,
          }
        }).filter(Boolean) as MultiSheetParseResult['sheets']

        resolve({ sheets })
      } catch (error) {
        reject(error)
      }
    }
    reader.onerror = () => reject(new Error('Failed to read file'))
    reader.readAsArrayBuffer(file)
  })
}

/**
 * Parse Excel file and return raw data
 */
export async function parseExcelFile(file: File): Promise<{ headers: string[]; data: any[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: 'array' })
        
        // Use first sheet by default (or could look for "Full week oppty view")
        const sheetName = workbook.SheetNames[0]
        const worksheet = workbook.Sheets[sheetName]
        
        // Convert to JSON with header row
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][]
        
        if (jsonData.length < 2) {
          reject(new Error('Excel file must have at least a header row and one data row'))
          return
        }

        const headers = jsonData[0].map((h: any) => String(h || '').trim())
        const dataRows = jsonData.slice(1).map((row) => {
          const obj: any = {}
          headers.forEach((header, idx) => {
            obj[header] = row[idx]
          })
          return obj
        })

        resolve({ headers, data: dataRows })
      } catch (error) {
        reject(error)
      }
    }
    reader.onerror = () => reject(new Error('Failed to read file'))
    reader.readAsArrayBuffer(file)
  })
}

/**
 * Apply header mapping and convert raw Excel data to ExceptionRow[]
 * RULE 1.2: Supports snapshot date assignment
 */
export function applyHeaderMap(
  rawData: any[],
  headerMap: HeaderMap,
  detectedHeaders: string[],
  snapshotDate?: string // Optional: provide snapshot date or detect from data
): ImportResult {
  const warnings: string[] = []
  const rows: ExceptionRow[] = []
  const detectedSnapshotDates = new Set<string>()

  for (let i = 0; i < rawData.length; i++) {
    const rawRow = rawData[i]
    
    try {
      // Map required fields
      const Material = getField(rawRow, headerMap.Material)
      const VendorName = getField(rawRow, headerMap.VendorName)
      const Planner = getField(rawRow, headerMap.Planner)
      const AccountSpecialist = getField(rawRow, headerMap.AccountSpecialist)
      const Plant = getField(rawRow, headerMap.Plant)
      const CurrentStatus = getField(rawRow, headerMap.CurrentStatus) || 'Not yet assessed'

      // Parse numeric fields
      const UnitsExcess = parseNumber(getField(rawRow, headerMap.UnitsExcess))
      const ExcessValue = parseNumber(getField(rawRow, headerMap.ExcessValue))

      // Skip rows with missing critical data
      if (!Material || !VendorName || !Planner || ExcessValue === null) {
        warnings.push(`Row ${i + 2}: Missing critical fields (Material, VendorName, Planner, or ExcessValue)`)
        continue
      }

      // Optional fields
      const MaterialName = getField(rawRow, headerMap.MaterialName) || null
      const PushOutToDate = parseExcelDate((rawRow as any)[headerMap.PushOutToDate || ''])
      const TimeFenceDays = parseNumber(getField(rawRow, headerMap.TimeFenceDays))
      const ExistingCategorization = getField(rawRow, headerMap.ExistingCategorization) || null
      const ValueStream = getField(rawRow, headerMap.ValueStream) || null
      const BusinessUnit = getField(rawRow, headerMap.BusinessUnit) || null
      const DaysOfInventoryOnHand = parseNumber(getField(rawRow, headerMap.DaysOfInventoryOnHand))

      // Parse constraints from multiple columns
      const constraints: string[] = []
      if (headerMap.Constraints && Array.isArray(headerMap.Constraints)) {
        headerMap.Constraints.forEach((col) => {
          const val = getField(rawRow, col)
          if (val) constraints.push(val)
        })
      }

      // Auto-detect optional columns
      const ExceptionDate = parseExcelDate((rawRow as any)['Date'])
      const Currency = getField(rawRow, 'Currency') || 'USD'
      const DocNumber = getField(rawRow, 'Doc Number') || null
      const Item = getField(rawRow, 'Item') || null
      const SchedLine = getField(rawRow, 'Sched.Line') || null
      const DeliveryDate = parseExcelDate((rawRow as any)['Delv. Date'])

      // RULE 1.2: Detect or assign snapshot date
      let rowSnapshotDate = snapshotDate
      if (!rowSnapshotDate) {
        // Try to detect from "Snapshot Date" column
        const detectedDate = parseExcelDate((rawRow as any)['Snapshot Date']) || 
                             parseExcelDate((rawRow as any)['Date']) ||
                             ExceptionDate
        rowSnapshotDate = detectedDate || new Date().toISOString().split('T')[0]
      }
      if (rowSnapshotDate) {
        detectedSnapshotDates.add(rowSnapshotDate)
      }

      // Compose ExceptionId
      let ExceptionId = ''
      if (DocNumber) {
        ExceptionId = DocNumber
        if (Item) ExceptionId += `-${Item}`
        if (SchedLine) ExceptionId += `-${SchedLine}`
      }
      if (!ExceptionId) {
        ExceptionId = generateGUID()
      }

      const row: ExceptionRow = {
        Material: Material!,
        MaterialName,
        VendorName: VendorName!,
        Planner: Planner!,
        AccountSpecialist: AccountSpecialist!,
        Plant: Plant!,
        UnitsExcess: UnitsExcess ?? 0,
        ExcessValue: ExcessValue ?? 0,
        PushOutToDate,
        TimeFenceDays,
        Constraints: constraints,
        ActionCategory: null,
        CurrentStatus,
        ExistingCategorization,
        ValueStream,
        BusinessUnit,
        DaysOfInventoryOnHand,

        ExceptionDate,
        Currency,
        DocNumber,
        Item,
        SchedLine,
        DeliveryDate,

        SnapshotDate: rowSnapshotDate!, // RULE 1.1

        ExceptionId,
        PriorityScore: 0, // Will be computed later
        ActionableFlag: false, // Will be computed later
        ActionedValue: 0,
        ThermometerPct: 0,

        ChangeLog: [],
      }

      rows.push(row)
    } catch (error) {
      warnings.push(`Row ${i + 2}: ${(error as Error).message}`)
    }
  }

  return { 
    rows, 
    warnings, 
    detectedHeaders,
    snapshotDates: Array.from(detectedSnapshotDates)
  }
}

/**
 * Export rows to Excel
 */
export function exportToExcel(rows: ExceptionRow[], options: ExportOptions): void {
  // Convert rows to a flat structure for Excel
  const flatRows = rows.map((row) => ({
    'Exception ID': row.ExceptionId,
    Material: row.Material,
    'Material Name': row.MaterialName || '',
    Vendor: row.VendorName,
    Planner: row.Planner,
    'Account Specialist': row.AccountSpecialist,
    Plant: row.Plant,
    'Units Excess': row.UnitsExcess,
    'Excess Value': row.ExcessValue,
    'Actioned Value': row.ActionedValue,
    'Thermometer %': row.ThermometerPct,
    'Current Status': row.CurrentStatus,
    'Action Category': row.ActionCategory || '',
    'Push Out To Date': row.PushOutToDate || '',
    'Time Fence Days': row.TimeFenceDays || '',
    'Days of Inventory': row.DaysOfInventoryOnHand || '',
    Constraints: row.Constraints.join('; '),
    'Existing Categorization': row.ExistingCategorization || '',
    'Value Stream': row.ValueStream || '',
    'Business Unit': row.BusinessUnit || '',
    Currency: row.Currency || 'USD',
    Notes: row.Notes || '',
  }))

  const worksheet = XLSX.utils.json_to_sheet(flatRows)
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Export')
  XLSX.writeFile(workbook, options.filename)
}

/**
 * Export a single row detail to Excel
 */
export function exportRowDetail(row: ExceptionRow): void {
  const detailData = [
    { Field: 'Exception ID', Value: row.ExceptionId },
    { Field: 'Material', Value: row.Material },
    { Field: 'Material Name', Value: row.MaterialName || '' },
    { Field: 'Vendor', Value: row.VendorName },
    { Field: 'Planner', Value: row.Planner },
    { Field: 'Account Specialist', Value: row.AccountSpecialist },
    { Field: 'Plant', Value: row.Plant },
    { Field: 'Units Excess', Value: row.UnitsExcess },
    { Field: 'Excess Value', Value: row.ExcessValue },
    { Field: 'Actioned Value', Value: row.ActionedValue },
    { Field: 'Thermometer %', Value: row.ThermometerPct },
    { Field: 'Current Status', Value: row.CurrentStatus },
    { Field: 'Action Category', Value: row.ActionCategory || '' },
    { Field: 'Existing Categorization', Value: row.ExistingCategorization || '' },
    { Field: 'Push Out To Date', Value: row.PushOutToDate || '' },
    { Field: 'Time Fence Days', Value: row.TimeFenceDays || '' },
    { Field: 'Days of Inventory', Value: row.DaysOfInventoryOnHand || '' },
    { Field: 'Constraints', Value: row.Constraints.join('; ') },
    { Field: 'Value Stream', Value: row.ValueStream || '' },
    { Field: 'Business Unit', Value: row.BusinessUnit || '' },
    { Field: 'Currency', Value: row.Currency || 'USD' },
    { Field: 'Notes', Value: row.Notes || '' },
  ]

  const worksheet = XLSX.utils.json_to_sheet(detailData)
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Detail')
  XLSX.writeFile(workbook, `${row.ExceptionId}_detail.xlsx`)
}

/**
 * Helper to get field from raw row using mapped header name
 */
function getField(rawRow: any, mappedHeader: string | string[] | null | undefined): string | null {
  if (!mappedHeader) return null
  if (Array.isArray(mappedHeader)) {
    // Should not happen for single fields, but handle gracefully
    return rawRow[mappedHeader[0]] ? String(rawRow[mappedHeader[0]]) : null
  }
  const value = rawRow[mappedHeader]
  return value !== undefined && value !== null ? String(value).trim() : null
}

/**
 * Parse number from string or number
 */
function parseNumber(value: string | number | null | undefined): number | null {
  if (value === null || value === undefined || value === '') return null
  const num = typeof value === 'number' ? value : parseFloat(String(value).replace(/[^0-9.-]/g, ''))
  return isNaN(num) ? null : num
}

/**
 * Parse Excel date - handles both serial numbers and date strings
 */
function parseExcelDate(value: any): string | null {
  if (!value) return null
  
  // If it's already a string date, return it
  if (typeof value === 'string') {
    // Try to parse it as a date
    const parsed = new Date(value)
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0]
    }
    return value
  }
  
  // If it's a number, it's an Excel serial date
  if (typeof value === 'number') {
    // Excel dates are days since 1900-01-01 (with leap year bug)
    const excelEpoch = new Date(1900, 0, 1)
    const days = value - 2 // Adjust for Excel's 1900 leap year bug
    const date = new Date(excelEpoch.getTime() + days * 24 * 60 * 60 * 1000)
    if (!isNaN(date.getTime())) {
      return date.toISOString().split('T')[0]
    }
  }
  
  // If it's a Date object
  if (value instanceof Date && !isNaN(value.getTime())) {
    return value.toISOString().split('T')[0]
  }
  
  return null
}

