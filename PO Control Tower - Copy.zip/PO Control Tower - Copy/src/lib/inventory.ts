import * as XLSX from 'xlsx'
import { ExceptionRow } from '@/types'

export interface InventoryData {
  material_number: string
  plant: string
  next_1year_requirements: number | null
  unrestricted_stock_quantity: number
  working_days: number
  // Additional fields for reference
  total_stock_quantity?: number
  safety_stock_quantity?: number
}

/**
 * Parse inventory Excel file
 */
export async function parseInventoryFile(file: File): Promise<Map<string, InventoryData>> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: 'array' })
        
        const sheetName = workbook.SheetNames[0]
        const worksheet = workbook.Sheets[sheetName]
        
        const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[]
        
        const inventoryMap = new Map<string, InventoryData>()
        const warnings: string[] = []
        let hasRequirements = false
        
        jsonData.forEach((row) => {
          const material_number = String(row.material_number || row['Material Number'] || '').trim()
          const plant = String(row.plant || row['Plant'] || '').trim()
          
          if (!material_number || !plant) return
          
          // Create composite key: Material-Plant
          const key = `${material_number}-${plant}`
          
          // Try to find requirements data (multiple possible column names)
          const next_1year_requirements = parseFloat(
            row.next_1year_requirements || 
            row['next_1year_requirements'] || 
            row['Next 1 Year Requirements'] || 
            row['annual_requirements'] ||
            row['yearly_demand'] ||
            0
          ) || null
          
          if (next_1year_requirements && next_1year_requirements > 0) {
            hasRequirements = true
          }
          
          const unrestricted_stock_quantity = parseFloat(
            row.unrestricted_stock_quantity || 
            row['Unrestricted Stock Quantity'] || 
            0
          )
          
          const total_stock_quantity = parseFloat(
            row.total_stock_quantity ||
            row['Total Stock Quantity'] ||
            0
          )
          
          const safety_stock_quantity = parseFloat(
            row.safety_stock_quantity ||
            row['Safety Stock Quantity'] ||
            0
          )
          
          // Working days - use 252 (standard business days per year) if not provided
          const working_days = parseFloat(row.working_days || row['Working Days'] || 252)
          
          inventoryMap.set(key, {
            material_number,
            plant,
            next_1year_requirements,
            unrestricted_stock_quantity,
            working_days,
            total_stock_quantity,
            safety_stock_quantity,
          })
        })

        if (!hasRequirements) {
          warnings.push('⚠️  No "next_1year_requirements" data found in inventory file.')
          warnings.push('    DIO cannot be calculated without annual requirements.')
          warnings.push('    The file has these columns: material_number, plant, unrestricted_stock_quantity, etc.')
          warnings.push('    Please ensure your file includes a requirements/demand column.')
          console.warn(warnings.join('\n'))
        }

        console.log(`Loaded ${inventoryMap.size} inventory records`)
        if (warnings.length > 0) {
          console.warn('Inventory data warnings:\n' + warnings.join('\n'))
        }
        resolve(inventoryMap)
      } catch (error) {
        reject(error)
      }
    }
    reader.onerror = () => reject(new Error('Failed to read inventory file'))
    reader.readAsArrayBuffer(file)
  })
}

/**
 * Calculate Days of Inventory On Hand (DIO)
 * 
 * Formula:
 * 1. pieces_per_day = next_1year_requirements / working_days
 * 2. DIO = unrestricted_stock_quantity / pieces_per_day
 */
export function calculateDIO(
  materialNumber: string,
  plant: string,
  inventoryMap: Map<string, InventoryData>
): number | null {
  const key = `${materialNumber}-${plant}`
  const inventory = inventoryMap.get(key)
  
  if (!inventory) return null
  
  const { next_1year_requirements, unrestricted_stock_quantity, working_days } = inventory
  
  // If no requirements, can't calculate meaningful DIO
  if (!next_1year_requirements || next_1year_requirements <= 0) return null
  
  // Calculate pieces per day
  const pieces_per_day = next_1year_requirements / working_days
  
  if (pieces_per_day <= 0) return null
  
  // Calculate DIO
  const dio = unrestricted_stock_quantity / pieces_per_day
  
  return dio
}

/**
 * Apply DIO calculations to all exception rows
 */
export function applyDIOToRows(
  rows: ExceptionRow[],
  inventoryMap: Map<string, InventoryData>
): ExceptionRow[] {
  return rows.map(row => {
    const dio = calculateDIO(row.Material, row.Plant, inventoryMap)
    return {
      ...row,
      DaysOfInventoryOnHand: dio,
    }
  })
}

