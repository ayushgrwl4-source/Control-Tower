import { RulesConfig, ExceptionRow } from '@/types'

/**
 * Determines if a row is actionable based on the rules configuration
 */
export function isActionable(row: ExceptionRow, rules: RulesConfig): boolean {
  const { sourceField, actionable } = rules
  
  // Get the value from the row based on sourceField
  const fieldValue = (row as any)[sourceField] || row.ExistingCategorization || ''
  const valueStr = String(fieldValue).trim()

  // Check deny list first
  if (actionable.denyExact.includes(valueStr)) {
    return false
  }

  // Check allow list
  if (actionable.allowExact.includes(valueStr)) {
    return true
  }

  // Apply fallback logic
  if (actionable.fallback === 'allow_if_not_denied') {
    // Already checked deny list, so allow
    return true
  } else {
    // deny_if_not_allowed: value must be in allowExact
    return false
  }
}

/**
 * Determines if a status counts as "actioned"
 */
export function isActionedStatus(status: string, rules: RulesConfig): boolean {
  return rules.actionedStatuses.includes(status)
}

/**
 * Load default rules from public folder
 */
export async function loadDefaultRules(): Promise<RulesConfig> {
  try {
    const response = await fetch('/default-rules.json')
    if (!response.ok) {
      throw new Error('Failed to load default rules')
    }
    return await response.json()
  } catch (error) {
    console.error('Error loading default rules:', error)
    // Return hardcoded fallback
    return {
      rulesVersion: 2,
      sourceField: 'PN EM Code Desc',
      actionedStatuses: ['Actioned', 'Approved Deviation', 'Escalated / Pending', 'Not yet assessed'],
      actionableLogic: 'custom',
      actionable: {
        denyExact: ['Do Not Action'],
        allowExact: ['Negotiation'],
        fallback: 'allow_if_not_denied',
      },
    }
  }
}

/**
 * Save rules to localStorage
 */
export function saveRulesToStorage(rules: RulesConfig): void {
  localStorage.setItem('po-control-tower:rules', JSON.stringify(rules))
}

/**
 * Load rules from localStorage, or use default
 */
export function loadRulesFromStorage(): RulesConfig | null {
  try {
    const stored = localStorage.getItem('po-control-tower:rules')
    if (stored) {
      return JSON.parse(stored)
    }
  } catch (error) {
    console.error('Error loading rules from storage:', error)
  }
  return null
}




