import { KPIRow } from '@/components/kpis/KPIRow'
import { FiltersBar } from '@/components/filters/FiltersBar'
import { ActionBoard } from '@/components/table/ActionBoard'
import { DetailDrawer } from '@/components/drawer/DetailDrawer'
import { Burndown } from '@/components/burndown/Burndown'
import { PrioritizationScatter } from '@/components/charts/PrioritizationScatter'
import { UploadButton } from '@/components/upload/UploadButton'
import { ExportButton } from '@/components/upload/ExportButton'
import { LoadSampleButton } from '@/components/upload/LoadSampleButton'
import { InventoryUploadButton } from '@/components/upload/InventoryUploadButton'
import { ClearDataButton } from '@/components/upload/ClearDataButton'
import { RiskDatePicker } from '@/components/filters/RiskDatePicker'
import { useStore } from '@/state/store'
import { useEffect, useState, useRef } from 'react'
import { loadDefaultRules } from '@/lib/rules'
import { parseExcelFileMultiSheet, applyHeaderMap } from '@/lib/excel'
import { isActionable } from '@/lib/rules'
import { SnapshotMetadata } from '@/types'
import { parseInventoryFile } from '@/lib/inventory'

// Helper to detect date from filename
function detectDateFromFilename(filename: string): string | null {
  const patterns = [
    /(\d{4})(\d{2})(\d{2})/,
    /(\d{4})-(\d{2})-(\d{2})/,
    /(\d{2})-(\d{2})-(\d{4})/,
    /(\d{1,2})-(\d{1,2})(?:\s|$)/,
  ]
  
  for (const pattern of patterns) {
    const match = filename.match(pattern)
    if (match) {
      if (match[1].length === 4) {
        return `${match[1]}-${match[2].padStart(2, '0')}-${match[3].padStart(2, '0')}`
      }
      if (match[3] && match[3].length === 4) {
        return `${match[3]}-${match[1].padStart(2, '0')}-${match[2].padStart(2, '0')}`
      }
      const month = match[1].padStart(2, '0')
      const day = match[2].padStart(2, '0')
      return `2025-${month}-${day}`
    }
  }
  return null
}

export default function Dashboard() {
  const setRules = useStore((state) => state.setRules)
  const rules = useStore((state) => state.rules)
  const addSnapshot = useStore((state) => state.addSnapshot)
  const setInventoryMap = useStore((state) => state.setInventoryMap)
  const headerMap = useStore((state) => state.headerMap)
  const rows = useStore((state) => state.rows)
  const [isLoading, setIsLoading] = useState(false)
  const hasLoadedRef = useRef(false) // Use ref instead of state to survive StrictMode

  useEffect(() => {
    // Load default rules on mount if not already loaded from localStorage
    if (!rules || !rules.rulesVersion) {
      loadDefaultRules().then((defaultRules) => {
        setRules(defaultRules)
      })
    }
  }, [])

  // Auto-load sample data on first mount (only if no data loaded)
  useEffect(() => {
    if (rows.length === 0 && !isLoading && !hasLoadedRef.current) {
      console.log('📥 Loading snapshots and DIO data...')
      hasLoadedRef.current = true // Set immediately to prevent double-load
      setIsLoading(true)
      loadDataAutomatically()
    }
  }, [])

  const loadDataAutomatically = async () => {
    // Auto-load EM snapshot files
    await loadEMSnapshotsAutomatically()
  }

  const loadInventoryData = async () => {
    try {
      console.log('📦 Loading inventory/DIO data (trimmed)...')
      const response = await fetch('/inventory-data-trimmed.xlsx')
      if (!response.ok) {
        console.warn('Trimmed inventory data not found, skipping')
        return
      }

      const blob = await response.blob()
      const file = new File([blob], 'inventory-data.xlsx', {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      })

      const inventoryMap = await parseInventoryFile(file)
      setInventoryMap(inventoryMap)
      
      let hasRequirements = false
      for (const inv of inventoryMap.values()) {
        if (inv.next_1year_requirements && inv.next_1year_requirements > 0) {
          hasRequirements = true
          break
        }
      }
      
      if (hasRequirements) {
        console.log(`✓ Loaded ${inventoryMap.size} inventory records with DIO calculations`)
      } else {
        console.warn(`⚠️  Loaded ${inventoryMap.size} inventory records but no requirements data found`)
      }
    } catch (error) {
      console.error('Error loading inventory data:', error)
    }
  }

  const processSnapshotFile = async (blob: Blob, filename: string) => {
    const file = new File([blob], filename, {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    })

    const result = await parseExcelFileMultiSheet(file)
    const filenameDate = detectDateFromFilename(filename)

    for (const sheet of result.sheets) {
      let snapshotDate = sheet.snapshotDate || filenameDate

      if (!snapshotDate) {
        const { snapshotDates } = applyHeaderMap(sheet.data.slice(0, 1), headerMap, sheet.headers)
        if (snapshotDates && snapshotDates.length > 0) {
          snapshotDate = snapshotDates[0]
        } else {
          snapshotDate = new Date().toISOString().split('T')[0]
        }
      }

      // Log ALL detected headers for debugging
      console.log(`📋 ${filename} has ${sheet.headers.length} columns:`)
      console.log(sheet.headers)
      
      // Log first row of data to see actual values
      if (sheet.data.length > 0) {
        console.log(`📄 First data row sample:`, sheet.data[0])
      }

      const { rows: sheetRows, warnings } = applyHeaderMap(
        sheet.data,
        headerMap,
        sheet.headers,
        snapshotDate
      )

      if (warnings.length > 0) {
        console.error(`❌ ${filename} has ${warnings.length} warnings:`)
        warnings.slice(0, 10).forEach(w => console.error(`   ${w}`))
      }
      
      console.log(`✅ Successfully parsed ${sheetRows.length} rows (out of ${sheet.data.length} total)`)

      const processedRows = sheetRows.map((row) => ({
        ...row,
        ActionableFlag: isActionable(row, rules),
      }))

      const metadata: SnapshotMetadata = {
        snapshotDate,
        importedAt: new Date().toISOString(),
        rowCount: processedRows.length,
        fileName: filename,
      }

      addSnapshot(processedRows, metadata)
      console.log(`✓ Loaded ${processedRows.length} rows from ${filename} (${snapshotDate})`)
    }
  }

  const loadEMSnapshotsAutomatically = async () => {
    try {
      // List of snapshot files to auto-load
      const snapshotFiles = [
        'EM 10-27 ALL LINES.xlsx',
      ]

      let totalLoaded = 0

      // Load trimmed DIO data (2.5MB - much faster!)
      await loadInventoryData()

      for (const filename of snapshotFiles) {
        try {
          console.log(`📥 Loading snapshot: ${filename}...`)
          const response = await fetch(`/${filename}`)
          if (!response.ok) {
            console.warn(`${filename} not found in public folder, trying data folder...`)
            // Try data folder as fallback
            const dataResponse = await fetch(`/data/${filename}`)
            if (!dataResponse.ok) {
              console.warn(`${filename} not found, skipping`)
              continue
            }
            const blob = await dataResponse.blob()
            await processSnapshotFile(blob, filename)
            continue
          }

          const blob = await response.blob()
          await processSnapshotFile(blob, filename)
          totalLoaded++
        } catch (fileError) {
          console.error(`Error loading ${filename}:`, fileError)
        }
      }

      if (totalLoaded > 0) {
        console.log(`✅ Auto-loaded ${totalLoaded} snapshot file(s)`)
      } else {
        console.warn('⚠️  No snapshot files found, skipping auto-load')
      }
    } catch (error) {
      console.error('Auto-load error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">PO Control Tower</h1>
              <p className="text-sm text-muted-foreground">
                Exception-driven control for excess purchase orders
                {isLoading && <span className="ml-2 text-blue-600">⏳ Loading data...</span>}
              </p>
            </div>
            <div className="flex gap-3 items-center">
              <RiskDatePicker />
              <div className="h-8 w-px bg-border" />
              <InventoryUploadButton />
              <LoadSampleButton />
              <UploadButton />
              <ExportButton />
              <div className="h-8 w-px bg-border" />
              <ClearDataButton />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading sample data...</p>
            </div>
          </div>
        ) : (
          <>
            {/* KPIs */}
            <KPIRow />

            {/* Burndown and Prioritization Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <Burndown />
              <PrioritizationScatter />
            </div>

            {/* Filters */}
            <FiltersBar />

            {/* Action Board */}
            <ActionBoard />
          </>
        )}
      </main>

      {/* Detail Drawer */}
      <DetailDrawer />
    </div>
  )
}
