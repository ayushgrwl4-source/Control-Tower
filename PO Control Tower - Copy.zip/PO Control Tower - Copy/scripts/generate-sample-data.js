/**
 * Script to generate sample Excel data for PO Control Tower
 * Run: node scripts/generate-sample-data.js
 */

import XLSX from 'xlsx'
import { writeFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Sample data configuration
const vendors = ['Acme Corp', 'Global Supplies Inc', 'Premium Parts Ltd', 'Quality Materials Co', 'Swift Logistics']
const planners = ['Alice Johnson', 'Bob Smith', 'Carol Williams', 'David Brown', 'Emma Davis']
const accountSpecialists = ['John Doe', 'Jane Smith', 'Mike Wilson', 'Sarah Lee', 'Tom Anderson']
const plants = ['Plant-001', 'Plant-002', 'Plant-003', 'Plant-004', 'Plant-005']
const engineFamilies = ['Engine A', 'Engine B', 'Engine C', 'Engine D']
const buyerGroups = ['BU-North', 'BU-South', 'BU-East', 'BU-West']
const statuses = ['Not yet assessed', 'In Progress', 'Actioned', 'Do Not Action', 'Escalated / Pending']
const pnEmCodes = ['Negotiation', 'Push Out', 'Cancel', 'Do Not Action', 'Review Required']
const constraintTypes = ['Within Guidelines', 'Exceeds Contract', 'No Contract', 'Special Approval Required']

function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function randomDate(start, end) {
  const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()))
  return date.toISOString().split('T')[0]
}

function generateSampleData(numRows = 200) {
  const data = []
  const startDate = new Date('2025-01-01')
  const endDate = new Date('2025-12-31')

  for (let i = 0; i < numRows; i++) {
    const docNumber = `DOC${10000 + i}`
    const materialNumber = `MAT-${1000 + randomInt(0, 500)}`
    const excessValue = randomInt(1000, 500000)
    const unitsExcess = randomInt(10, 10000)
    const status = randomItem(statuses)

    data.push({
      'Doc Number': docNumber,
      'Item': randomInt(10, 99),
      'Sched.Line': randomInt(1, 5),
      'Material Number': materialNumber,
      'Vendor Name': randomItem(vendors),
      'Material Planner': randomItem(planners),
      'Account Specialist': randomItem(accountSpecialists),
      'Plant': randomItem(plants),
      'Outst.Qty.': unitsExcess,
      'Remaining Opportunity, $': excessValue,
      'Resch. Date': randomDate(startDate, endDate),
      'Contractual Firm Zone (Days)': randomInt(0, 90),
      'Status vs. Guideline': status,
      'Status vs Contracts': randomItem(constraintTypes),
      'Guideline vs Contract': randomItem(constraintTypes),
      'Contract Exceptions': Math.random() > 0.7 ? randomItem(constraintTypes) : '',
      'PN EM Code Desc': randomItem(pnEmCodes),
      'Engine Family': randomItem(engineFamilies),
      'Buyer Group': randomItem(buyerGroups),
      'Date': randomDate(new Date('2025-10-20'), new Date('2025-10-27')),
      'Currency': 'USD',
      'Lead-time': randomInt(7, 120),
      'Sum of Days to Push': randomInt(0, 60),
      'Delv. Date': randomDate(startDate, endDate),
      'Confirmed': Math.random() > 0.5 ? 'Yes' : 'No',
      'ASN Number': Math.random() > 0.6 ? `ASN${randomInt(10000, 99999)}` : '',
    })
  }

  return data
}

function main() {
  console.log('Generating sample data...')
  const sampleData = generateSampleData(250)

  // Create worksheet
  const worksheet = XLSX.utils.json_to_sheet(sampleData)

  // Create workbook
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Full week oppty view')

  // Write to file
  const outputPath = join(__dirname, '..', 'public', 'sample-data.xlsx')
  XLSX.writeFile(workbook, outputPath)

  console.log(`✓ Sample data generated: ${outputPath}`)
  console.log(`  Rows: ${sampleData.length}`)
}

main()




