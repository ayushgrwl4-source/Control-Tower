# Inventory Risk Calculator Feature

## Overview

Added a date-based inventory risk calculator to identify potential inventory shortages if exceptions are not actioned by a specific date.

---

## Location

**Top Right** of the dashboard header, next to the Import/Export buttons:
- Calendar icon with "Inventory Risk Date" date picker
- Separator line
- Load Sample Data / Import / Export buttons

---

## How It Works

### Risk Calculation Logic

Inventory risk is calculated based on items where:

1. **Delivery Date** (`Delv. Date`) is **BEFORE** the selected date
   - Item was originally scheduled to arrive by this date
   
2. **Reschedule Date** (`Resch. Date`) is **AFTER** the selected date
   - Item has been pushed out beyond this date

**This creates inventory shortage risk** because:
- You were expecting the inventory by the target date
- It's now been rescheduled to arrive after that date
- If the exception isn't actioned, you'll have an inventory gap

---

## How to Use

### Step 1: Select a Date
Click the **"Inventory Risk Date"** picker in the top right and choose a target date.

### Step 2: View Risk KPI
A new **orange KPI card** appears showing:
- **Total Risk Value** (in dollars)
- **Number of at-risk items**
- **Risk date** being analyzed
- Explanation of what the risk means

### Step 3: Take Action
The KPI shows you the total dollar value at risk if exceptions aren't actioned. Review and action the critical items.

---

## Example Scenarios

### Scenario 1: Weekly Planning
**Question**: "What's my inventory risk for next Monday if I don't action these exceptions?"

**Steps**:
1. Select next Monday's date
2. See the risk value
3. Identify which exceptions create the risk
4. Prioritize actioning those items

---

### Scenario 2: Month-End Analysis
**Question**: "What inventory shortage am I facing at month-end?"

**Steps**:
1. Select the last day of the month
2. View total risk exposure
3. Plan actions to mitigate the risk

---

### Scenario 3: Critical Date
**Question**: "We have a production run on Dec 15. What's my risk?"

**Steps**:
1. Select December 15
2. See exactly how much inventory won't arrive in time
3. Action the high-value exceptions immediately

---

## Visual Design

### Date Picker (Top Right)
- Calendar icon
- "Inventory Risk Date" label
- Date input field
- Clear button (X) to remove the date

### Risk KPI Card (When Date Selected)
- **Orange border** and background (warning color)
- **Alert triangle icon** 
- **Risk value** in large orange text
- **Badge** showing:
  - Red badge with item count if there's risk
  - Gray "No Risk" badge if no risk
- **Date** being analyzed
- **Explanation** of what the risk represents

---

## KPI Layout

### Without Risk Date:
```
┌─────────────┬─────────────┬─────────────┐
│Total Excess │ Actionable  │ % Actioned  │
│             │   Excess    │             │
└─────────────┴─────────────┴─────────────┘
```

### With Risk Date Selected:
```
┌─────────────┬─────────────┬─────────────┬─────────────┐
│Total Excess │ Actionable  │ % Actioned  │ Inventory   │
│             │   Excess    │             │    Risk     │
└─────────────┴─────────────┴─────────────┴─────────────┘
```

---

## Understanding the Risk

### What Creates Risk?
An item creates inventory risk when:
- **Expected arrival**: Before your target date
- **Actual arrival**: After your target date (due to reschedule)
- **Result**: Inventory shortage on your target date

### Example:
- Target Date: **Dec 1, 2024**
- Delivery Date: **Nov 25, 2024** (before target)
- Reschedule Date: **Dec 10, 2024** (after target)
- **Result**: This item creates risk - it won't be here when you need it

### What Doesn't Create Risk?
- Items originally scheduled to arrive after your target date (no expectation)
- Items rescheduled but still arriving before your target date (still on time)
- Items with no delivery or reschedule dates (can't determine)

---

## Technical Details

### Risk Calculation Function
**Location**: `src/lib/risk.ts`

```typescript
function calculateInventoryRisk(rows, riskDate) {
  // Returns:
  // - riskValue: Total $ at risk
  // - riskCount: Number of items
  // - riskRows: Array of risky items
}
```

### Date Comparison
- Normalizes all dates to start of day (00:00:00)
- Compares using strict inequality:
  - `deliveryDate < targetDate`
  - `rescheduleDate > targetDate`

---

## Files Created/Modified

### New Files:
1. `src/components/filters/RiskDatePicker.tsx` - Date picker component
2. `src/components/kpis/RiskKPI.tsx` - Risk KPI card
3. `src/lib/risk.ts` - Risk calculation logic

### Modified Files:
1. `src/types/index.ts` - Added `riskDate` to FilterState
2. `src/state/store.ts` - Added riskDate to default filters
3. `src/state/selectors.ts` - Added `useInventoryRisk()` hook
4. `src/components/kpis/KPIRow.tsx` - Added conditional 4th KPI
5. `src/pages/Dashboard.tsx` - Added RiskDatePicker to header

---

## Performance

- ✅ **Memoized**: Only recalculates when date changes
- ✅ **Fast**: Efficient filtering on 14,000+ rows
- ✅ **Instant**: Updates happen immediately

---

## To See It in Action

1. **Refresh your browser**
2. Look in the **top right** for the date picker
3. Select a date (try 30 days from now)
4. Watch the **4th orange KPI card** appear
5. See your total inventory risk

---

**This feature helps you proactively identify and mitigate inventory shortages!** 🎯



