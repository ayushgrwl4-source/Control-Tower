# Supply Chain Control Tower - Simulation Rules

**Version:** 1.0  
**Last Updated:** 2025-10-28  
**Authority:** This document is the single source of truth for all business logic in the PO Control Tower webapp.

---

## 1. DATA MODEL & SNAPSHOTS

### RULE 1.1: Multi-Snapshot Support
The webapp SHALL support loading and managing multiple snapshots of exception data from different dates.

**Behavior:**
- Each snapshot is identified by a unique snapshot date
- Users can load multiple Excel files with different snapshot dates
- Each row in the exception data MUST have a `SnapshotDate` field
- If the Excel file contains a "Date" column, use it as the snapshot date
- If no date column exists, prompt the user to provide a snapshot date during import
- All snapshots are stored in a unified data structure keyed by ExceptionId + SnapshotDate

### RULE 1.2: Snapshot Date Detection
When parsing Excel files, the system SHALL attempt to detect snapshot dates in this order:
1. Check if file has multiple sheets named with dates (e.g., "2025-10-21", "10-22-2025")
2. Check for a "Date" or "Snapshot Date" column in the data
3. Check for date in filename (e.g., "20251021-20251026 Full week opportunity.xlsx")
4. If no date detected, prompt user to select/enter the snapshot date

### RULE 1.3: Exception Identity
An exception record is uniquely identified by:
- `ExceptionId`: Composed from Doc Number + Item + Sched.Line (or generated GUID if missing)
- `SnapshotDate`: The date this snapshot was taken

**Composite Key:** `{ExceptionId}-{SnapshotDate}`

---

## 2. ACTIONABLE LOGIC

### RULE 2.1: Actionable Flag Computation
The `ActionableFlag` field determines whether an exception should be included in actionable metrics.

**Source Field:** Configurable via `rules.sourceField` (default: "PN EM Code Desc")

**Logic Type:** Configurable via `rules.actionableLogic`:
- `"custom"`: Use rules.actionable configuration (default)
- `"all"`: All rows are actionable
- `"none"`: No rows are actionable

**Custom Logic (when actionableLogic = "custom"):**
1. If the source field value is in `rules.actionable.denyExact[]`, return FALSE
2. If the source field value is in `rules.actionable.allowExact[]`, return TRUE
3. Otherwise, use `rules.actionable.fallback`:
   - `"allow_if_not_denied"`: Return TRUE (default)
   - `"deny_if_not_allowed"`: Return FALSE

**Default Configuration:**
```json
{
  "denyExact": ["Do Not Action"],
  "allowExact": ["Negotiation"],
  "fallback": "allow_if_not_denied"
}
```

### RULE 2.2: Actioned Status
A row is considered "actioned" if its `CurrentStatus` is in the `rules.actionedStatuses[]` array.

**Default Actioned Statuses:**
- "Actioned"
- "Approved Deviation"
- "Escalated / Pending"
- "Not yet assessed"

### RULE 2.3: Actioned Value Computation
```
ActionedValue = (CurrentStatus is in actionedStatuses) ? ExcessValue : 0
```

### RULE 2.4: Rejection Cause
Planners can optionally mark exceptions with a rejection reason using the `RejectionCause` field.

**Behavior:**
- The `RejectionCause` field is optional and defaults to NULL (no rejection)
- When set, indicates why an exception cannot be actioned
- Rejection causes are tracked in the audit log (RULE 10.3)
- Used for analysis and reporting on common rejection patterns

**Placeholder Rejection Causes (to be updated later):**
- `DUPLICATE_ORDER`: Order already exists in system
- `ALREADY_RESOLVED`: Exception has been resolved outside the system
- `CONTRACTUAL_OBLIGATION`: Cannot reject due to contract terms
- `SUPPLIER_COMMITMENT`: Committed to supplier
- `DOWNSTREAM_DEPENDENCY`: Other processes depend on this order
- `PRODUCTION_REQUIREMENT`: Required for production schedule
- `INCORRECT_DATA`: Data is incorrect or invalid
- `CUSTOMER_REQUIREMENT`: Customer-mandated requirement
- `OTHER`: Other reason (see Notes field)

---

## 3. DERIVED FIELDS

### RULE 3.1: Days of Inventory on Hand (DIO)
If inventory data is loaded via the DIO Data import:

```
DIO = unrestricted_stock_quantity / (next_1year_requirements / working_days)
```

Where:
- `unrestricted_stock_quantity`: Current stock level
- `next_1year_requirements`: Annual demand forecast
- `working_days`: Number of working days per year (default: 252)

**Key:** Material-Plant composite key

### RULE 3.2: Thermometer Percentage
```
ThermometerPct = (ExcessValue > 0) ? (ActionedValue / ExcessValue) * 100 : 0
```

### RULE 3.3: Priority Score
Higher score = higher priority for action.

```
PriorityScore = (ExcessValue * 1,000,000) 
                + (DaysOfInventoryOnHand * 1,000) 
                - (ExceptionDate.getTime() / 100,000)
```

---

## 4. KPI CALCULATIONS

### RULE 4.1: Total Opportunity
Sum of `ExcessValue` for all rows where `ActionableFlag = TRUE`.

### RULE 4.2: Total Actioned
Sum of `ActionedValue` for all rows where `ActionableFlag = TRUE`.

### RULE 4.3: Completion Percentage
```
Completion% = (TotalActioned / TotalOpportunity) * 100
```

### RULE 4.4: Weekly KPIs
Weekly metrics are computed using `weekStart` and `weekEnd` date filters:
- Filter rows where `ExceptionDate` falls within the week
- Apply same opportunity/actioned/completion calculations

---

## 5. FILTERING & GROUPING

### RULE 5.1: Available Filters
- **Search:** Free text search across Material, VendorName, MaterialName
- **Planner:** Multi-select filter on Planner field
- **Vendor:** Multi-select filter on VendorName field
- **Plant:** Multi-select filter on Plant field
- **Account Specialist:** Multi-select filter on AccountSpecialist field
- **Status:** Multi-select filter on CurrentStatus field
- **Actionable Only:** Boolean toggle to show only ActionableFlag = TRUE
- **Value Range:** Min/Max filter on ExcessValue
- **DIO Range:** Min/Max filter on DaysOfInventoryOnHand
- **Date Range:** Start/End date filter on ExceptionDate
- **Risk Date:** Filter rows where PushOutToDate is before this date
- **Snapshot Date:** (NEW) Multi-select filter to show specific snapshots
- **Base Currency:** Display currency (default: USD)

### RULE 5.2: Grouping Modes
- `"none"`: No grouping, flat list
- `"planner"`: Group by Planner
- `"vendor"`: Group by VendorName
- `"plant"`: Group by Plant
- `"status"`: Group by CurrentStatus

---

## 6. SNAPSHOT VISUALIZATION & COMPARISON

### RULE 6.1: Snapshot Selector UI
The webapp SHALL provide a snapshot date selector that allows:
- Viewing a single snapshot
- Viewing multiple snapshots simultaneously
- Comparing two snapshots side-by-side

### RULE 6.2: Trend Analysis
When multiple snapshots are loaded:
- Show trend lines for Total Opportunity over time
- Show trend lines for Completion % over time
- Highlight new exceptions (appear in later snapshots but not earlier)
- Highlight resolved exceptions (appear in earlier snapshots but not later)

### RULE 6.3: Burndown Chart with Snapshots
The Burndown chart SHALL:
- Plot Total Opportunity over snapshot dates (time series)
- Plot Total Actioned over snapshot dates
- Show target/goal line if configured
- Update dynamically as filters change

---

## 7. DATA PERSISTENCE

### RULE 7.1: Local Storage Strategy
To avoid localStorage quota limits:
- Store only CHANGED rows (rows with ChangeLog entries)
- Store: ExceptionId, SnapshotDate, CurrentStatus, ActionCategory, RejectionCause, Notes, LastUpdatedBy, LastUpdatedAt, ChangeLog
- Do NOT store full dataset or computed fields

### RULE 7.2: Snapshot Storage
- Store snapshot metadata (snapshot date, import timestamp, row count) in localStorage
- Store full snapshot data in memory during session
- Provide export functionality to save snapshots to Excel

---

## 8. IMPORT/EXPORT

### RULE 8.1: Multi-Sheet Excel Import
If an Excel file contains multiple sheets with date-named sheets:
- Detect all sheets with date patterns (YYYY-MM-DD, MM-DD-YYYY, etc.)
- Import each sheet as a separate snapshot
- Show progress indicator during multi-sheet import

### RULE 8.2: Date Column Detection
If Excel has a "Date" column:
- Use this as the SnapshotDate for each row
- Allow rows with different dates in the same file

### RULE 8.3: Export with Snapshots
Export functionality SHALL:
- Export current view (filtered data) to Excel
- Option to export specific snapshot(s)
- Option to export comparison between two snapshots
- Include snapshot date in the exported filename

---

## 9. HEADER MAPPING

### RULE 9.1: Default Header Map
The system uses a configurable header mapping to handle varying Excel column names:

```json
{
  "Material": "Material Number",
  "MaterialName": null,
  "VendorName": "Vendor Name",
  "Planner": "Material Planner",
  "AccountSpecialist": "Account Specialist",
  "Plant": "Plant",
  "UnitsExcess": "Outst.Qty.",
  "ExcessValue": "Remaining Opportunity, $",
  "PushOutToDate": "Resch. Date",
  "TimeFenceDays": "Contractual Firm Zone (Days)",
  "Constraints": ["Status vs. Guideline", "Status vs Contracts"],
  "CurrentStatus": "Status vs. Guideline",
  "ExistingCategorization": "PN EM Code Desc",
  "ValueStream": "Engine Family",
  "BusinessUnit": "Buyer Group",
  "DaysOfInventoryOnHand": null
}
```

---

## 10. AUDIT & CHANGE TRACKING

### RULE 10.1: Change Log Structure
Every status change creates an audit entry:
```json
{
  "timestamp": "ISO-8601 datetime",
  "user": "username",
  "field": "CurrentStatus",
  "oldValue": "previous value",
  "newValue": "new value"
}
```

### RULE 10.2: Auto-Update Fields
When a row is updated:
- `LastUpdatedBy`: Set to current user
- `LastUpdatedAt`: Set to current timestamp (ISO-8601)
- Append audit entry to `ChangeLog[]`

### RULE 10.3: Rejection Cause Tracking
Rejection cause changes are tracked in the audit log:
```json
{
  "timestamp": "ISO-8601 datetime",
  "user": "username",
  "field": "RejectionCause",
  "oldValue": "previous cause or null",
  "newValue": "new cause or null"
}
```

---

## CHANGELOG

### DEC-0001: Initial Rules Creation
**Date:** 2025-10-28 14:30 UTC  
**Author:** User  
**Summary:** Created simulation_rules.md with multi-snapshot support specifications

**Changes Implemented:**
- Documented multi-snapshot data model (RULE 1.1, 1.2, 1.3)
- Documented snapshot date detection logic
- Documented actionable logic (RULE 2.1, 2.2, 2.3)
- Documented derived field calculations (RULE 3.1, 3.2, 3.3)
- Documented KPI calculations (RULE 4.x)
- Documented filtering, grouping, and visualization rules (RULE 5.x, 6.x)
- Documented data persistence and import/export rules (RULE 7.x, 8.x)
- Documented header mapping and audit tracking (RULE 9.x, 10.x)

**Files To Be Changed:**
- src/types/index.ts - Add SnapshotDate field and snapshot-related types
- src/state/store.ts - Update state to support snapshot map
- src/lib/excel.ts - Add multi-sheet and date detection parsing
- src/components/upload/UploadButton.tsx - Add snapshot date picker dialog
- src/components/filters/FiltersBar.tsx - Add snapshot selector
- src/components/burndown/Burndown.tsx - Update for time-series snapshots
- src/components/kpis/KPIRow.tsx - Update for snapshot-aware KPIs
- src/pages/Dashboard.tsx - Add snapshot management UI

**Known Limitations:**
- Currency conversion not yet implemented (placeholder for future)
- Multi-snapshot comparison view to be implemented in phase 2

**Follow-ups:**
- Test with the provided file: "20251021-20251026 Full week opportunity.xlsx"
- Add snapshot trend visualization
- Add snapshot export functionality

---

### DEC-0002: Multi-Snapshot Implementation Complete
**Date:** 2025-10-28 15:45 UTC  
**Author:** AI Assistant  
**Summary:** Implemented full multi-snapshot support with date detection, filtering, and time-series visualization

**Sync Summary:**

**Rules Implemented:**
- RULE 1.1: Multi-snapshot data model with SnapshotDate field on ExceptionRow
- RULE 1.2: Snapshot date detection from sheet names, filenames, and data columns
- RULE 1.3: Composite key using ExceptionId + SnapshotDate
- RULE 5.1: Snapshot date filter in FiltersBar
- RULE 6.3: Burndown chart with time-series visualization for multiple snapshots
- RULE 7.2: Snapshot metadata storage
- RULE 8.1: Multi-sheet Excel import support

**Files Changed:**

1. **src/types/index.ts**
   - Added `SnapshotDate: string` field to ExceptionRow
   - Added `snapshotDates: string[]` filter to FilterState
   - Added `SnapshotMetadata` interface for tracking snapshot imports
   - Added `MultiSheetParseResult` interface for multi-sheet parsing

2. **src/lib/excel.ts**
   - Added `detectDateFromSheetName()` helper function
   - Added `detectDateFromFilename()` helper function (utility for future use)
   - Added `parseExcelFileMultiSheet()` function to parse all sheets with date detection
   - Updated `applyHeaderMap()` to accept optional `snapshotDate` parameter
   - Auto-detect snapshot dates from "Snapshot Date" or "Date" columns
   - Return detected snapshot dates in ImportResult

3. **src/state/store.ts**
   - Added `snapshotMetadata: Map<string, SnapshotMetadata>` to AppState
   - Updated `setRows()` to support `appendMode` parameter
   - Added `addSnapshot()` action to add snapshots with metadata
   - Added `getAvailableSnapshots()` selector to list all snapshot dates
   - Updated default filters to include `snapshotDates: []`

4. **src/state/selectors.ts**
   - Added snapshot date filtering logic to `useFilteredRows()`
   - Added `snapshotDates` to `useFilterOptions()` return value
   - Filters now support multi-select snapshot date filtering

5. **src/components/upload/UploadButton.tsx**
   - Refactored to use `parseExcelFileMultiSheet()` instead of single-sheet parser
   - Process each sheet as a separate snapshot
   - Auto-detect snapshot dates from sheet names or prompt user
   - Create `SnapshotMetadata` for each imported snapshot
   - Use `addSnapshot()` instead of `setRows()` to preserve existing data
   - Display import summary showing number of snapshots imported

6. **src/components/filters/FiltersBar.tsx**
   - Added snapshot date multi-select filter UI
   - Shows count of available snapshots
   - Only displays when snapshots are available
   - Empty selection = show all snapshots
   - Integrated with `useFilterOptions()` to get available dates

7. **src/components/burndown/Burndown.tsx**
   - Added multi-snapshot detection logic
   - Implemented time-series trend visualization when multiple snapshots loaded
   - Shows 3 lines: Total Opportunity, Actioned, Remaining over snapshot dates
   - Displays snapshot analysis comparing first/last snapshots
   - Falls back to weekly burndown view for single snapshot
   - Fully compliant with RULE 6.3

**Key Features Delivered:**
- ✅ Multi-sheet Excel file import (each sheet = 1 snapshot)
- ✅ Auto-detection of snapshot dates from sheet names (YYYY-MM-DD, YYYYMMDD, MM/DD/YYYY patterns)
- ✅ Fallback to Date column detection
- ✅ User prompt for missing dates
- ✅ Snapshot metadata tracking (date, import time, row count, filename)
- ✅ Snapshot date filter in UI (multi-select)
- ✅ Time-series burndown chart for trend analysis
- ✅ Backward compatible with single-snapshot workflows

**Testing:**
- Ready to test with "20251021-20251026 Full week opportunity.xlsx"
- Dev server started for manual testing
- All linter errors resolved (1 minor warning for unused utility function)

**Known Limitations:**
- Snapshot comparison (side-by-side) view not yet implemented (deferred to phase 2)
- Snapshot-specific export functionality to be added
- Currency conversion still placeholder (as documented in DEC-0001)

**Database/Storage Impact:**
- Snapshot metadata stored in memory during session
- LocalStorage strategy unchanged (only changed rows persisted)
- No quota issues expected as full snapshots not persisted to localStorage

---

### DEC-0004: Rejection Cause Field
**Date:** 2025-10-30 16:00 UTC  
**Author:** User  
**Summary:** Added optional rejection cause dropdown for planners to track why exceptions cannot be actioned

**Sync Summary:**

**Rules Implemented:**
- RULE 2.4: Rejection Cause - Optional field with placeholder values
- RULE 10.3: Rejection cause changes tracked in audit log
- RULE 7.1: Updated to include RejectionCause in localStorage persistence

**Files Changed:**

1. **src/types/index.ts**
   - Added `RejectionCause?: string | null` field to ExceptionRow
   - Field is optional and defaults to null (no rejection)

2. **src/components/table/RejectionSelect.tsx** (NEW)
   - Created new dropdown component for rejection causes
   - Implements 9 placeholder rejection causes:
     - No Rejection, Duplicate Order, Already Resolved, Contractual Obligation
     - Supplier Commitment, Downstream Dependency, Production Requirement
     - Incorrect Data, Customer Requirement, Other
   - Integrated with store's `updateRowRejectionCause` action
   - Includes audit trail logging

3. **src/components/table/ActionBoard.tsx**
   - Added RejectionSelect import
   - Added "Rejection Cause" column (240px width) between Status and PN EM Code Desc
   - Included rejection dropdown in expanded group rows (changed grid to 7 columns)
   - Integrated rejection select with click event handling

4. **src/components/drawer/DetailDrawer.tsx**
   - Added RejectionSelect import
   - Added rejection cause dropdown in inline editing section
   - Positioned between Status and Action Category fields
   - Full integration with audit trail

5. **src/state/store.ts**
   - Added `updateRowRejectionCause` action to AppState interface
   - Implemented rejection cause update logic with audit trail:
     - Creates AuditEntry for each change
     - Updates LastUpdatedBy and LastUpdatedAt
     - Appends to ChangeLog
   - Updated localStorage persistence to include RejectionCause field
   - Follows same pattern as updateRowStatus for consistency

6. **simulation_rules.md**
   - Documented RULE 2.4: Rejection Cause field and behavior
   - Documented RULE 10.3: Rejection cause audit tracking
   - Updated RULE 7.1 to include RejectionCause in storage strategy
   - Added this changelog entry (DEC-0004)

**Key Features Delivered:**
- ✅ Rejection cause dropdown with 9 placeholder options
- ✅ Full audit trail for rejection cause changes
- ✅ Integrated into table view, grouped view, and detail drawer
- ✅ Persisted to localStorage with other changed fields
- ✅ Follows existing patterns (StatusSelect) for consistency
- ✅ Ready for future customization of rejection causes

**User Notes:**
- Rejection causes are PLACEHOLDER values as requested
- Can be easily updated later by modifying the `rejectionCauses` array in RejectionSelect.tsx
- Null/empty value = "No Rejection"
- All changes are audited and tracked

**Testing:**
- Ready for manual testing in development environment
- Dropdown appears in table alongside Status column
- Changes are logged to console and persisted to localStorage

**Known Limitations:**
- Rejection causes are hardcoded placeholders (will be updated per user request)
- No filtering by rejection cause yet (can be added if needed)
- No analytics/reporting on rejection patterns yet (future enhancement)

---

### DEC-0003: Snapshot Display Logic Refinement
**Date:** 2025-10-28 16:15 UTC  
**Author:** AI Assistant  
**Summary:** Fixed Y-axis formatting and clarified snapshot filtering behavior

**Changes:**
1. **Burndown Chart Improvements:**
   - Fixed Y-axis labels (now shows $1.2M instead of 000,000)
   - Added wider Y-axis (80px) for better number display
   - Simplified currency format: $1.2M for millions, $500K for thousands
   - Fixed value calculations - now shows total excess per snapshot correctly
   - Enhanced snapshot analysis summary with percentage change
   - Labeled as "Day-over-Day" trending

2. **Snapshot Filtering Logic:**
   - **Table & Scatterplot**: Auto-filter to LATEST snapshot only (user requirement)
   - **Burndown Chart**: Always shows ALL snapshots for trend analysis
   - When new snapshot imported, automatically selects latest in filter
   - User can still manually change snapshot filter if needed
   - Added tooltip: "Select snapshot dates for table/scatterplot. Burndown shows all dates for trending."

**Files Changed:**
- `src/components/burndown/Burndown.tsx` - Fixed chart formatting and calculations
- `src/state/store.ts` - Auto-select latest snapshot on import
- `src/components/filters/FiltersBar.tsx` - Improved filter labels and tooltips

**Behavior:**
- Import multi-date file → Latest snapshot auto-selected for table
- Burndown always shows full trend across all dates
- Clear separation between "view current state" (table) and "track progress" (burndown)

