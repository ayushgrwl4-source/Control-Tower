# Setup Instructions for New Company

This is a clean copy of the PO Control Tower webapp, ready to be configured for a new company.

## Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm run dev
   ```

3. **Build for Production**
   ```bash
   npm run build
   npm run preview
   ```

## Initial Configuration

### 1. Update Company-Specific Information
- Update `README.md` with the new company name and details
- Review `simulation_rules.md` and adjust any business rules specific to the new company

### 2. Configure Header Mapping
- Edit `public/default-header-map.json` to match the Excel column names from the new company's data files
- The current mapping is configured for the previous company - you'll need to adjust it

### 3. Configure Business Rules
- Edit `public/default-rules.json` to set:
  - Actionable statuses
  - Actioned statuses  
  - Source fields for calculations
  - Any other company-specific business logic

### 4. Add Your Data
- Upload Excel files using the "Upload Data" button in the webapp
- The system supports multi-snapshot imports (multiple sheets with different dates)
- Refer to `simulation_rules.md` for details on data format requirements

## Data Requirements

Your Excel file should contain columns that map to these fields:
- Material Number
- Vendor Name
- Material Planner
- Plant
- Excess Value/Opportunity
- Current Status
- Exception Date
- (Optional) Snapshot Date

See `public/default-header-map.json` for the full list of mappable fields.

## Clean State

This installation comes with:
- ✅ All source code and components
- ✅ Default configuration files
- ✅ No company-specific data
- ✅ No node_modules (run `npm install`)
- ✅ Clean git history (if you want to initialize: `git init`)

## Documentation

- `simulation_rules.md` - Business logic and rules reference
- `README.md` - Application overview
- See inline code comments for technical details

## Support

For questions about the webapp functionality, refer to the original project or the simulation_rules.md documentation.

