# Prioritization Scatterplot Feature

## Overview

Added a scatterplot chart showing site/item prioritization based on DIO (Days of Inventory On Hand) and Excess $ value.

---

## Location

**Right side of Burndown Chart** - Dashboard now has a 2-column chart layout:
```
┌─────────────────────────┬─────────────────────────┐
│   Weekly Burndown       │  Site Prioritization    │
│   (80% Reduction)       │  by DIO and Excess $    │
└─────────────────────────┴─────────────────────────┘
```

---

## What It Shows

### Visual Representation
A scatterplot with:
- **X-axis**: Current DIO (Days of Inventory On Hand)
- **Y-axis**: Excess $ value
- **Points**: Top ~100 items/groups based on current view
- **Color-coded priorities**:
  - 🔵 **Dark Blue** (Navy) = High priority
  - 🔵 **Blue** = Medium priority  
  - ⚪ **Gray** = Low priority

### Priority Zones

The chart is divided into zones with curved boundary lines:

**High Priority** (Dark Blue):
- High excess $ value
- AND/OR low DIO (running out soon)
- **Action**: Address immediately

**Medium Priority** (Blue):
- Moderate excess $ and DIO
- **Action**: Monitor and schedule

**Low Priority** (Gray):
- Lower excess $ value
- AND higher DIO (plenty of inventory)
- **Action**: Lower urgency

---

## How It Works

### When Ungrouped (Group by = None)
- Shows **top 100 individual exceptions** by excess value
- Each dot = one exception
- Filters out items without DIO data
- Sorted by excess value (largest first)

### When Grouped (Vendor, Planner, etc.)
- Shows **top 100 groups** by total excess value
- Each dot = one group
- **DIO = Weighted average** of group items
  - `Weighted DIO = Σ(item.DIO × item.ExcessValue) / Σ(item.ExcessValue)`
- Group label shown on hover

---

## Priority Calculation

**Formula**:
```typescript
valueScore = (excessValue / $100k) × 100  // Capped at 100
dioScore = 100 - (dio / 365) × 100       // Lower DIO = higher score
combinedScore = valueScore × 70% + dioScore × 30%

If combinedScore >= 70 → High priority
If combinedScore >= 40 → Medium priority
Else → Low priority
```

**Logic**:
- Excess value weighted 70% (more important)
- DIO weighted 30% (secondary factor)
- High excess + low DIO = Highest priority
- Low excess + high DIO = Lowest priority

---

## Interactive Features

### Hover Tooltip
Shows:
- Item/Group name
- Exact excess value (formatted currency)
- Exact DIO (days)
- Priority level

### Legend
- Bottom of chart shows color coding
- "Showing top X items/groups with DIO data"

### Responsive
- Adapts to current filters
- Updates when grouping changes
- Only shows items with DIO data available

---

## Use Cases

### 1. **Identify Critical Items**
Dark blue dots in upper-left quadrant = High value + Low DIO
→ These need immediate action!

### 2. **Compare Groups**
When grouped by Vendor/Planner:
- See which vendors/planners have highest risk
- Compare relative excess $ vs inventory levels

### 3. **Spot Outliers**
Items far from the cluster may need special attention:
- Very high DIO with low value
- Very low DIO with high value

### 4. **Track Progress**
As you action items:
- High priority dots should move to actioned status
- Scatterplot updates to show remaining exceptions

---

## Visual Design

### Chart Elements:
- **Grid lines**: Dotted background for reference
- **Curved zones**: Subtle orange boundary lines between priorities
- **Color-blind safe**: Navy/Blue/Gray palette
- **Clean legend**: Shows priority levels at bottom
- **Axis labels**: "Current DIO" (X) and "Excess $" (Y)

### Layout:
- Burndown on the **left**
- Scatterplot on the **right**
- Equal width on large screens
- Stacked on smaller screens

---

## Data Quality

### Requirements:
- Items must have **DIO value > 0** to appear
- Items with null/zero DIO are filtered out
- Shows message: "Showing top X items with DIO data"

### Performance:
- **Limited to top 100** items/groups for clarity
- Prevents overcrowding
- Fast rendering even with 14k+ exceptions
- Memoized calculations

---

## Example Interpretations

### Scenario 1: High Priority Item
- **Position**: Upper-left (high Y, low X)
- **Excess**: $500,000
- **DIO**: 10 days
- **Meaning**: Half million dollars at risk, only 10 days of inventory left
- **Action**: TOP PRIORITY - action immediately

### Scenario 2: Low Priority Item
- **Position**: Lower-right (low Y, high X)
- **Excess**: $5,000
- **DIO**: 200 days
- **Meaning**: Small value, plenty of inventory
- **Action**: Low urgency

### Scenario 3: Medium Priority Item
- **Position**: Middle zone
- **Excess**: $50,000
- **DIO**: 60 days
- **Meaning**: Moderate value and inventory
- **Action**: Schedule for review

---

## Changes Made

### New Files:
1. `src/components/charts/PrioritizationScatter.tsx` - Scatterplot component

### Modified Files:
1. `src/pages/Dashboard.tsx` - Added scatterplot to layout
2. `src/components/burndown/Burndown.tsx` - Removed bottom margin
3. `src/components/table/ActionBoard.tsx` - Changed "DOI" to "DIO"

### Layout Changes:
- Charts now in 2-column grid (lg screens)
- Stack on smaller screens
- Both charts have equal visual weight

---

## Column Label Fix

### Before:
- ❌ "DOI" (incorrect)

### After:
- ✅ "DIO" (correct)

**DIO = Days of Inventory On Hand** (industry standard terminology)

---

## 🔄 Refresh Your Browser

You'll see:

1. **Two charts side-by-side**:
   - Left: Weekly Burndown
   - Right: Prioritization Scatterplot

2. **Top 100 items** plotted by DIO vs Excess $

3. **Color-coded priorities** (Navy/Blue/Gray)

4. **Table column** now says "DIO" instead of "DOI"

5. **Interactive tooltips** on hover

---

## Future Enhancements (Optional)

Potential additions:
- [ ] Click dots to filter table to those items
- [ ] Adjustable priority thresholds
- [ ] Zoom/pan on chart
- [ ] Export chart as image
- [ ] Show more/fewer than 100 points

---

**Your prioritization scatterplot is ready!** Refresh to see the new visualization. 📊



