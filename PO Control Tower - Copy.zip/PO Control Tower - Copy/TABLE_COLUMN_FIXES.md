# Table Column Fixes

## Issues Fixed

### 1. ✅ Removed Plant Column from Part View
**Issue**: Plant column was showing in the part-level view (when not grouped) but wasn't needed.

**Fix**: Removed the `Plant` column from the individual row columns.

**Impact**: Cleaner, more focused table with only relevant columns.

---

### 2. ✅ Removed Time Fence Column from Part View
**Issue**: Time Fence (Days) column was showing but wasn't critical for the part view.

**Fix**: Removed the `TimeFenceDays` column from the individual row columns.

**Impact**: Less clutter, easier to scan the important data.

---

### 3. ✅ Fixed Column Switching Between Views
**Issue**: When switching from Part view → Vendor view → Part view, the columns didn't revert to the correct format.

**Root Cause**: 
- React was reusing the table component between view switches
- Column dependencies weren't complete (missing `maxValue`)
- Table wasn't forcing a fresh render on grouping mode changes

**Fixes Applied**:
1. Added `maxValue` to the `useMemo` dependencies for columns
2. Added `key={groupingMode}` to the Card component to force React to remount when grouping changes

**Impact**: Columns now update correctly every time you switch views.

---

## Updated Column Order (Part View)

When **Group by = None** (part-level view):

1. **Value (Bar Chart)** - Proportional bar showing excess value
2. **Material** - Material number + name
3. **Vendor** - Vendor name
4. **Planner** - Material planner
5. **Units Excess** - Quantity
6. **DOI** - Days of inventory on hand
7. **Action Category** - Category field
8. **Status** - Status dropdown (220px wide)
9. **PN EM Code Desc** - Categorization
10. **Push Out Date** - Rescheduled date
11. **Constraints** - Constraint information

**Removed**:
- ❌ Plant (removed)
- ❌ Time Fence (removed)

---

## Columns Still Available in Detail Drawer

Even though Plant and Time Fence were removed from the table, they're still visible in:
- **Detail Drawer** - Click any row to see ALL fields including Plant and Time Fence
- **Export** - Excel exports include all fields

---

## Technical Details

### Files Modified:
**src/components/table/ActionBoard.tsx**

### Changes Made:

1. **Removed Plant column** (lines ~151-154)
```typescript
// REMOVED:
{
  accessorKey: 'Plant',
  header: 'Plant',
},
```

2. **Removed TimeFenceDays column** (lines ~193-200)
```typescript
// REMOVED:
{
  accessorKey: 'TimeFenceDays',
  header: 'Time Fence',
  cell: ({ row }) => {
    const days = (row.original as ExceptionRow).TimeFenceDays
    return days !== null ? `${days}d` : '—'
  },
},
```

3. **Updated useMemo dependencies**
```typescript
// BEFORE:
}, [groupingMode, expandedGroups])

// AFTER:
}, [groupingMode, expandedGroups, maxValue])
```

4. **Added React key to force remount**
```typescript
// BEFORE:
<Card className="mb-6">

// AFTER:
<Card className="mb-6" key={groupingMode}>
```

---

## Why the Key Fix Works

React's `key` prop tells React to treat components with different keys as completely different instances:

- **Part view** → `key="none"` → React creates a fresh table
- **Vendor view** → `key="vendor"` → React destroys old table, creates new one
- **Back to Part** → `key="none"` → React creates a fresh table again

This ensures columns always match the current grouping mode.

---

## Testing

To verify the fixes:

1. **Refresh your browser**
2. **Check Part View**:
   - Verify Plant column is gone
   - Verify Time Fence column is gone
   - Table should feel cleaner

3. **Test View Switching**:
   - Start at Part view (Group by = None)
   - Switch to Vendor view (Group by = Vendor)
   - Switch back to Part view (Group by = None)
   - ✅ Columns should correctly show part view columns

4. **Try Other Groupings**:
   - Test Part, Vendor, Planner, Account Specialist, Value Stream, Business Unit
   - Each time you switch, verify the correct columns appear

---

## Performance

All fixes maintain:
- ✅ Virtual scrolling for 14,000+ rows
- ✅ Fast column switching
- ✅ Smooth rendering
- ✅ No performance degradation

---

**All fixes are live!** Refresh your browser to see the cleaner table and correct column switching. 🎉



